import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { AddressInfo } from 'net';
import http from 'http';
import { createApp } from './app';
import { Repository, ADMIN_EMAIL } from './repository';
import { getFirestore, Collections } from './db';
import { signAuthToken, COOKIE_NAME } from './auth';
import { getBangladeshToday, getBangladeshTomorrow } from '../src/utils/bangladeshTime';

describe('Phase 1: Member Meal Authorization & ON/OFF Controls', () => {
  let server: http.Server;
  let baseUrl: string;

  const memberAId = 'mem-test-a';
  const memberBId = 'mem-test-b';

  let tokenMemberA: string;
  let tokenMemberB: string;
  let tokenAdmin: string;

  beforeAll(async () => {
    // 1. Create test members in DB
    const db = getFirestore();
    await db.collection(Collections.MEMBERS).doc(memberAId).set({
      id: memberAId,
      fullName: 'আব্দুর রহিম (Rahim)',
      email: 'rahim@test.com',
      isActive: true,
      joinDate: '2026-01-01',
      initialDeposit: 0,
      password: 'password123',
    });

    await db.collection(Collections.MEMBERS).doc(memberBId).set({
      id: memberBId,
      fullName: 'করিম চৌধুরী (Karim)',
      email: 'karim@test.com',
      isActive: true,
      joinDate: '2026-01-01',
      initialDeposit: 0,
      password: 'password123',
    });

    // 2. Create sessions & tokens
    const sessA = `sess_a_${Date.now()}`;
    await Repository.createSession(sessA, memberAId, 'member', 'rahim@test.com', memberAId);
    tokenMemberA = signAuthToken({
      sessionId: sessA,
      userId: memberAId,
      memberId: memberAId,
      email: 'rahim@test.com',
      role: 'member',
    });

    const sessB = `sess_b_${Date.now()}`;
    await Repository.createSession(sessB, memberBId, 'member', 'karim@test.com', memberBId);
    tokenMemberB = signAuthToken({
      sessionId: sessB,
      userId: memberBId,
      memberId: memberBId,
      email: 'karim@test.com',
      role: 'member',
    });

    const sessAdmin = `sess_admin_${Date.now()}`;
    await Repository.createSession(sessAdmin, 'admin-1', 'admin', ADMIN_EMAIL, 'mem-1');
    tokenAdmin = signAuthToken({
      sessionId: sessAdmin,
      userId: 'admin-1',
      memberId: 'mem-1',
      email: ADMIN_EMAIL,
      role: 'admin',
    });

    // 3. Start app
    const app = createApp();
    server = app.listen(0);
    const port = (server.address() as AddressInfo).port;
    baseUrl = `http://127.0.0.1:${port}`;
  });

  afterAll(async () => {
    if (server) {
      await new Promise<void>((resolve) => server.close(() => resolve()));
    }
  });

  it('(a) member A toggles own meal -> 200', async () => {
    const tomorrow = getBangladeshTomorrow();
    const res = await fetch(`${baseUrl}/api/mess/member/${memberAId}/meal`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenMemberA}`,
      },
      body: JSON.stringify({
        date: tomorrow,
        mealCount: 1,
        lunch: true,
        dinner: false,
      }),
    });

    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data.success).toBe(true);
  });

  it('(b) member A toggles member B\'s meal -> 403 ("অন্য মেম্বারের তথ্যে প্রবেশাধিকার নেই।")', async () => {
    const tomorrow = getBangladeshTomorrow();
    const res = await fetch(`${baseUrl}/api/mess/member/${memberBId}/meal`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenMemberA}`,
      },
      body: JSON.stringify({
        date: tomorrow,
        mealCount: 2,
        lunch: true,
        dinner: true,
      }),
    });

    expect(res.status).toBe(403);
    const data = await res.json();
    expect(data.success).toBe(false);
    expect(data.error).toBe('অন্য মেম্বারের তথ্যে প্রবেশাধিকার নেই।');
  });

  it('(c) admin toggles any member\'s meal -> 200', async () => {
    const tomorrow = getBangladeshTomorrow();
    const res = await fetch(`${baseUrl}/api/mess/member/${memberBId}/meal`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenAdmin}`,
      },
      body: JSON.stringify({
        date: tomorrow,
        mealCount: 2,
        lunch: true,
        dinner: true,
      }),
    });

    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data.success).toBe(true);
  });

  it('(d) a day past the lock time returns the lock error for members, not the access error', async () => {
    const today = getBangladeshToday();
    const res = await fetch(`${baseUrl}/api/mess/member/${memberAId}/meal`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenMemberA}`,
      },
      body: JSON.stringify({
        date: today,
        mealCount: 0,
        lunch: false,
        dinner: false,
      }),
    });

    expect(res.status).toBe(403);
    const data = await res.json();
    expect(data.success).toBe(false);
    expect(data.error).toBe('এই দিনের মিল পরিবর্তনের সময় শেষ হয়ে গেছে (লক করা হয়েছে)।');
  });

  it('(e) "All ON / All OFF" bulk actions call the API with the correct member id', async () => {
    const tomorrow = getBangladeshTomorrow();

    // 1. Member A sets ALL_ON for Member A -> 200
    const allOnRes = await fetch(`${baseUrl}/api/mess/member/${memberAId}/meal`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenMemberA}`,
      },
      body: JSON.stringify({
        date: tomorrow,
        mealCount: 2,
        lunch: true,
        dinner: true,
      }),
    });
    expect(allOnRes.status).toBe(200);

    // 2. Member A sets ALL_OFF for Member A -> 200
    const allOffRes = await fetch(`${baseUrl}/api/mess/member/${memberAId}/meal`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenMemberA}`,
      },
      body: JSON.stringify({
        date: tomorrow,
        mealCount: 0,
        lunch: false,
        dinner: false,
      }),
    });
    expect(allOffRes.status).toBe(200);

    // 3. Member A attempting ALL_ON on Member B -> 403
    const crossRes = await fetch(`${baseUrl}/api/mess/member/${memberBId}/meal`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenMemberA}`,
      },
      body: JSON.stringify({
        date: tomorrow,
        mealCount: 2,
        lunch: true,
        dinner: true,
      }),
    });
    expect(crossRes.status).toBe(403);
    const crossData = await crossRes.json();
    expect(crossData.error).toBe('অন্য মেম্বারের তথ্যে প্রবেশাধিকার নেই।');
  });

  it('(f) GET /api/mess/auth/me returns full user details with name from database', async () => {
    const res = await fetch(`${baseUrl}/api/mess/auth/me`, {
      headers: {
        Authorization: `Bearer ${tokenMemberA}`,
      },
    });

    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data.success).toBe(true);
    expect(data.user).toBeDefined();
    expect(data.user.memberId).toBe(memberAId);
    expect(data.user.id).toBe(memberAId);
    expect(data.user.email).toBe('rahim@test.com');
    expect(data.user.role).toBe('member');
    expect(data.user.name).toBe('আব্দুর রহিম (Rahim)');
  });

  it('(g) Alias routes /api/mess/me and /api/mess/me/meal work seamlessly for authenticated member', async () => {
    const tomorrow = getBangladeshTomorrow();
    // Test alias POST /me/meal
    const mealRes = await fetch(`${baseUrl}/api/mess/me/meal`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenMemberA}`,
      },
      body: JSON.stringify({
        date: tomorrow,
        mealCount: 1,
        lunch: true,
        dinner: false,
      }),
    });
    expect(mealRes.status).toBe(200);

    // Test alias GET /me
    const getRes = await fetch(`${baseUrl}/api/mess/me`, {
      headers: {
        Authorization: `Bearer ${tokenMemberA}`,
      },
    });
    expect(getRes.status).toBe(200);
    const getData = await getRes.json();
    expect(getData.success).toBe(true);
    expect(getData.data.member.id).toBe(memberAId);
  });

  it('(h) Member toggles meal using /api/mess/member/me/meal -> 200', async () => {
    const tomorrow = getBangladeshTomorrow();
    const res = await fetch(`${baseUrl}/api/mess/member/me/meal`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenMemberA}`,
      },
      body: JSON.stringify({
        date: tomorrow,
        mealCount: 2,
        lunch: true,
        dinner: true,
      }),
    });
    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data.success).toBe(true);
  });

  it('(i) Member accesses /api/mess/member/me -> 200 with member data', async () => {
    const res = await fetch(`${baseUrl}/api/mess/member/me`, {
      headers: {
        Authorization: `Bearer ${tokenMemberA}`,
      },
    });
    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data.success).toBe(true);
    expect(data.data.member.id).toBe(memberAId);
  });

  it('(j) Member accesses /api/mess/member/me/deposits -> 200', async () => {
    const res = await fetch(`${baseUrl}/api/mess/member/me/deposits`, {
      headers: {
        Authorization: `Bearer ${tokenMemberA}`,
      },
    });
    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data.success).toBe(true);
    expect(Array.isArray(data.data)).toBe(true);
  });
});
