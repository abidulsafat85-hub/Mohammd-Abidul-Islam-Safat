/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useCallback, useRef, lazy, Suspense } from 'react';
import {
  Member,
  MealRecord,
  BazarExpense,
  Deposit,
  FixedExpense,
  MessSettings,
  PollVoteStatus,
  AuthUser,
} from './types';
import { ApiService } from './services/apiService';
import { calculateMonthlySummary } from './services/calculations';
import { getCurrentMonthString, getTodayString } from './utils/dateUtils';
import {
  Routes,
  Route,
  Navigate,
  useLocation,
  useNavigate,
  useSearchParams,
} from 'react-router-dom';
import { AlertTriangle, WifiOff } from 'lucide-react';
import { Sidebar, NavTab } from './components/layout/Sidebar';
import { BottomNav } from './components/layout/BottomNav';
import { Header } from './components/layout/Header';
import { ShareLinksModal } from './components/admin/ShareLinksModal';
import { LoginView } from './components/auth/LoginView';
import { AdminForcePasswordChange } from './components/auth/AdminForcePasswordChange';
import { HomePage } from './pages/HomePage';
import { NotFoundPage } from './pages/NotFoundPage';
import { PullToRefresh } from './components/common/PullToRefresh';
import { DEFAULT_APP_NAME, DEFAULT_LOGO } from './constants/branding';

// Big screens load only when they are opened, so the first page download is much smaller.
const DashboardView = lazy(() => import('./components/dashboard/DashboardView').then((m) => ({ default: m.DashboardView })));
const MealEntryView = lazy(() => import('./components/meals/MealEntryView').then((m) => ({ default: m.MealEntryView })));
const MembersView = lazy(() => import('./components/members/MembersView').then((m) => ({ default: m.MembersView })));
const BazarView = lazy(() => import('./components/bazar/BazarView').then((m) => ({ default: m.BazarView })));
const DepositsView = lazy(() => import('./components/deposits/DepositsView').then((m) => ({ default: m.DepositsView })));
const MonthlyReportView = lazy(() => import('./components/reports/MonthlyReportView').then((m) => ({ default: m.MonthlyReportView })));
const CalendarHistoryView = lazy(() => import('./components/history/CalendarHistoryView').then((m) => ({ default: m.CalendarHistoryView })));
const SettingsView = lazy(() => import('./components/settings/SettingsView').then((m) => ({ default: m.SettingsView })));
const WhatsAppPollView = lazy(() => import('./components/whatsapp/WhatsAppPollView').then((m) => ({ default: m.WhatsAppPollView })));
const MemberPortalView = lazy(() => import('./components/member/MemberPortalView').then((m) => ({ default: m.MemberPortalView })));
const RegisterPage = lazy(() => import('./pages/RegisterPage').then((m) => ({ default: m.RegisterPage })));
const OrderPage = lazy(() => import('./pages/OrderPage').then((m) => ({ default: m.OrderPage })));
const OrderStatusPage = lazy(() => import('./pages/OrderStatusPage').then((m) => ({ default: m.OrderStatusPage })));
const MemberMealPage = lazy(() => import('./components/member/MemberMealPage').then((m) => ({ default: m.MemberMealPage })));
const MemberHistoryPage = lazy(() => import('./components/member/MemberHistoryPage').then((m) => ({ default: m.MemberHistoryPage })));
const MemberPaymentPage = lazy(() => import('./components/member/MemberPaymentPage').then((m) => ({ default: m.MemberPaymentPage })));
const MemberComplaintsPage = lazy(() => import('./components/member/MemberComplaintsPage').then((m) => ({ default: m.MemberComplaintsPage })));
const MemberProfilePage = lazy(() => import('./components/member/MemberProfilePage').then((m) => ({ default: m.MemberProfilePage })));
const OrdersView = lazy(() => import('./components/admin/OrdersView').then((m) => ({ default: m.OrdersView })));

function RouteFallback() {
  return (
    <div className="flex min-h-[40vh] items-center justify-center text-sm text-slate-500">
      লোড হচ্ছে...
    </div>
  );
}

// Compare only the fields that matter, so a change is detected without sending whole lists.
type SyncKey = 'members' | 'meals' | 'bazar' | 'deposits' | 'fixedExpenses';
const SYNC_SPECS: Record<SyncKey, { key: (x: any) => string; sig: (x: any) => string }> = {
  members: {
    key: (x) => String(x.id),
    sig: (x) =>
      JSON.stringify([x.fullName, x.nickname || '', x.phone || '', x.email || '', x.joinDate || '', Number(x.initialDeposit) || 0, x.isActive !== false, x.notes || '', x.address || '', x.studentId || '']),
  },
  meals: {
    key: (x) => `${x.memberId}__${x.date}`,
    sig: (x) => JSON.stringify([Number(x.mealCount) || 0, Boolean(x.lunch), Boolean(x.dinner)]),
  },
  bazar: {
    key: (x) => String(x.id),
    sig: (x) => JSON.stringify([x.date, x.description || '', x.category || '', Number(x.amount) || 0, x.paidByMemberId || '', x.note || '']),
  },
  deposits: {
    key: (x) => String(x.id),
    sig: (x) => JSON.stringify([x.memberId, x.date, Number(x.amount) || 0, x.paymentMethod || '', x.note || '', x.status || '']),
  },
  fixedExpenses: {
    key: (x) => String(x.id),
    sig: (x) => JSON.stringify([x.month, x.title || '', Number(x.amount) || 0, x.paidByMemberId || '']),
  },
};
const SYNC_KEYS: SyncKey[] = ['members', 'meals', 'bazar', 'deposits', 'fixedExpenses'];
const emptySnapshot = (): Record<SyncKey, Map<string, string>> => ({
  members: new Map(),
  meals: new Map(),
  bazar: new Map(),
  deposits: new Map(),
  fixedExpenses: new Map(),
});

const ADMIN_EMAIL = 'abidulsafat85@gmail.com';

export default function App() {
  // Authentication State: loaded synchronously from localStorage if available, then verified from server
  const [authUser, setAuthUser] = useState<AuthUser | null>(() => {
    try {
      const stored = localStorage.getItem('messmate_auth_user');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });
  const [authChecking, setAuthChecking] = useState<boolean>(true);

  // Check if current authenticated user is the Admin / Manager
  const isAdmin = useMemo(() => {
    return authUser?.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase();
  }, [authUser]);

  // Mode: for Admin, can toggle between 'admin' and 'member' preview; for other users, strictly 'member'
  const [appMode, setAppMode] = useState<'admin' | 'member'>('admin');

  // Active Member ID for Member Portal
  const [activeMemberId, setActiveMemberId] = useState<string | null>(null);

  // Modals
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  // Navigation tabs for Admin Panel: 1st Meal Entry then Dashboard
  const [currentTab, setCurrentTab] = useState<NavTab>('meals');
  const [selectedMonth, setSelectedMonth] = useState<string>(() => getCurrentMonthString());
  const [todayStr, setTodayStr] = useState<string>(() => getTodayString());

  // Quick Action Modal states in Admin
  const [openQuickDeposit, setOpenQuickDeposit] = useState(false);

  // Auto-update live date and synchronize automatically on rollover, interval, or focus
  useEffect(() => {
    const syncLiveDate = () => {
      const nowToday = getTodayString();
      setTodayStr(nowToday);
    };

    const interval = setInterval(syncLiveDate, 30000);
    const handleFocus = () => syncLiveDate();
    window.addEventListener('focus', handleFocus);
    window.addEventListener('visibilitychange', handleFocus);

    return () => {
      clearInterval(interval);
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener('visibilitychange', handleFocus);
    };
  }, []);

  // Core Data loaded directly from Firestore API (Section 4a)
  const [members, setMembers] = useState<Member[]>([]);
  const [meals, setMeals] = useState<MealRecord[]>([]);
  const [bazar, setBazar] = useState<BazarExpense[]>([]);
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [fixedExpenses, setFixedExpenses] = useState<FixedExpense[]>([]);
  const [settings, setSettings] = useState<MessSettings>({
    appName: DEFAULT_APP_NAME,
    messName: DEFAULT_APP_NAME,
    logo: DEFAULT_LOGO,
    subtitle: 'ঘরের তৈরি স্বাস্থ্যকর খাবারের নির্ভরযোগ্য ঠিকানা',
    currency: '৳',
    mealRateMode: 'bazar_only',
    defaultMealsPerDay: 2,
    theme: 'light',
    fixedMealRate: 50,
  });

  // Accidental Empty State & Sync protection states (Item 5)
  const [stateError, setStateError] = useState<string | null>(null);
  const [isStateLoading, setIsStateLoading] = useState<boolean>(false);
  const loadServerStateRef = useRef<(silent?: boolean) => Promise<void>>(async () => {});
  const loadServerState = useCallback((silent?: boolean) => loadServerStateRef.current(silent), []);

  // What the server last told us. Used to send ONLY real changes (never whole lists),
  // so new registrations or member meal changes made meanwhile are never overwritten.
  const serverSnapshotRef = useRef<Record<SyncKey, Map<string, string>>>(emptySnapshot());
  const pendingSyncCount = useRef(0);
  const lastStateLoadRef = useRef(0);

  const syncToServer = useCallback(
    (
      customState?: Partial<{
        members: Member[];
        meals: MealRecord[];
        bazar: BazarExpense[];
        deposits: Deposit[];
        fixedExpenses: FixedExpense[];
        settings: MessSettings;
      }>,
      opts?: { noDeletes?: boolean }
    ) => {
      if (!customState) return;
      const current: Record<SyncKey, any[]> = { members, meals, bazar, deposits, fixedExpenses };
      const upserts: Record<string, any[]> = {};
      const deletes: Record<string, any[]> = {};
      const nextMaps: Partial<Record<SyncKey, Map<string, string>>> = {};
      let hasChanges = false;

      for (const name of SYNC_KEYS) {
        const target = customState[name] as any[] | undefined;
        if (target === undefined) continue;

        // Safety: never wipe a whole list in one go because of an accidental empty list
        if (target.length === 0 && current[name].length > 1) {
          console.warn('[Sync Guard] Blocked attempt to send empty list as sync to server.');
          continue;
        }

        const spec = SYNC_SPECS[name];
        const snap: Map<string, string> = serverSnapshotRef.current[name];
        const targetMap = new Map<string, string>();
        for (const item of target) targetMap.set(spec.key(item), spec.sig(item));

        const ups = target.filter((item) => snap.get(spec.key(item)) !== spec.sig(item));
        const delKeys: string[] = opts?.noDeletes ? [] : Array.from<string>(snap.keys()).filter((k) => !targetMap.has(k));

        if (ups.length === 0 && delKeys.length === 0) continue;
        hasChanges = true;
        if (ups.length) upserts[name] = ups;
        if (delKeys.length) {
          deletes[name] =
            name === 'meals'
              ? delKeys.map((k) => {
                  const i = k.lastIndexOf('__');
                  return { memberId: k.slice(0, i), date: k.slice(i + 2) };
                })
              : delKeys;
        }
        nextMaps[name] = targetMap;
      }

      if (!hasChanges) return;

      pendingSyncCount.current += 1;
      ApiService.syncState({ upserts, deletes })
        .then(() => {
          for (const name of SYNC_KEYS) {
            const t = nextMaps[name];
            if (!t) continue;
            const snap: Map<string, string> = serverSnapshotRef.current[name];
            for (const item of (upserts[name] || [])) snap.set(SYNC_SPECS[name].key(item), SYNC_SPECS[name].sig(item));
            const dels = deletes[name] || [];
            for (const d of dels) snap.delete(name === 'meals' ? `${d.memberId}__${d.date}` : String(d));
          }
        })
        .catch((err) => {
          console.warn('Sync to server failed:', err);
          setStateError('সার্ভারে পরিবর্তন সেভ করা যায়নি। সার্ভারের সর্বশেষ তথ্য দেখানো হচ্ছে।');
          loadServerState(true);
        })
        .finally(() => {
          pendingSyncCount.current -= 1;
        });
    },
    [members, meals, bazar, deposits, fixedExpenses]
  );

  // Retry and Connection state for robust session verification (Item 2)
  const [retryNotice, setRetryNotice] = useState<string | null>(null);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [isMockDatabase, setIsMockDatabase] = useState<boolean>(false);

  // Verify Session with 3 retries on network error before showing retry prompt (Item 2a)
  const verifySession = useCallback(async () => {
    setAuthChecking(true);
    setConnectionError(null);

    const delays = [1000, 2000, 3000];
    for (let attempt = 0; attempt <= 3; attempt++) {
      try {
        const result = await ApiService.getMe();
        if (result.status === 'authenticated') {
          setAuthUser(result.user);
          try {
            localStorage.setItem('messmate_auth_user', JSON.stringify(result.user));
          } catch {}
          setRetryNotice(null);
          setConnectionError(null);
          setAuthChecking(false);
          return;
        }

        if (result.status === 'unauthenticated') {
          // Only real 401/403 clears the user (Item 2a)
          setAuthUser(null);
          setActiveMemberId(null);
          localStorage.removeItem('messmate_auth_user');
          setRetryNotice(null);
          setConnectionError(null);
          setAuthChecking(false);
          return;
        }

        // Temporary network or server error: keep user signed in, show notice and retry up to 3 times
        if (attempt < 3) {
          setRetryNotice('সংযোগে সমস্যা, আবার চেষ্টা হচ্ছে...');
          await new Promise((resolve) => setTimeout(resolve, delays[attempt]));
        } else {
          // Never silently log out on temporary failure
          setRetryNotice(null);
          setConnectionError('সংযোগে সমস্যা হচ্ছে। অনুগ্রহ করে ইন্টারনেট সংযোগ পরীক্ষা করে পুনরায় চেষ্টা করুন।');
          setAuthChecking(false);
          return;
        }
      } catch {
        if (attempt < 3) {
          setRetryNotice('সংযোগে সমস্যা, আবার চেষ্টা হচ্ছে...');
          await new Promise((resolve) => setTimeout(resolve, delays[attempt]));
        } else {
          setRetryNotice(null);
          setConnectionError('সংযোগে সমস্যা হচ্ছে। অনুগ্রহ করে ইন্টারনেট সংযোগ পরীক্ষা করে পুনরায় চেষ্টা করুন।');
          setAuthChecking(false);
          return;
        }
      }
    }
  }, []);


  // Load server state with Item 5 safety guard: keep old data if fails or returns empty list
  const loadServerStateImpl = useCallback(async (silent?: boolean) => {
    const isSilent = silent === true;
    if (!isSilent) setIsStateLoading(true);
    if (!isSilent) setStateError(null);
    try {
      lastStateLoadRef.current = Date.now();
      const serverState = await ApiService.getFullState();
      if (!serverState) {
        throw new Error('সার্ভার থেকে কোনো তথ্য পাওয়া যায়নি।');
      }

      // Remember what the server has, so later saves can send only the real differences
      for (const name of SYNC_KEYS) {
        if (Array.isArray(serverState[name])) {
          const spec = SYNC_SPECS[name];
          const map = new Map<string, string>();
          for (const item of serverState[name]) map.set(spec.key(item), spec.sig(item));
          serverSnapshotRef.current[name] = map;
        }
      }

      if (serverState.isMockDatabase === true) {
        setIsMockDatabase(true);
      }

      // Guard: If server returns empty list while screen already had data, KEEP OLD DATA!
      setMembers((prev) => {
        if (Array.isArray(serverState.members)) {
          if (serverState.members.length === 0 && prev.length > 0) {
            setStateError('সার্ভারে মেম্বার তালিকা ফাঁকা পাওয়া গেছে। পূর্বের তথ্য অপরিবর্তিত রাখা হয়েছে।');
            return prev;
          }
          return serverState.members;
        }
        return prev;
      });

      setMeals((prev) => {
        if (Array.isArray(serverState.meals)) {
          if (serverState.meals.length === 0 && prev.length > 0) {
            setStateError((e) => e || 'সার্ভারে মিলের তালিকা ফাঁকা পাওয়া গেছে। পূর্বের তথ্য অপরিবর্তিত রাখা হয়েছে।');
            return prev;
          }
          return serverState.meals;
        }
        return prev;
      });

      setDeposits((prev) => {
        if (Array.isArray(serverState.deposits)) {
          if (serverState.deposits.length === 0 && prev.length > 0) {
            setStateError((e) => e || 'সার্ভারে জমার তালিকা ফাঁকা পাওয়া গেছে। পূর্বের তথ্য অপরিবর্তিত রাখা হয়েছে।');
            return prev;
          }
          return serverState.deposits;
        }
        return prev;
      });

      setBazar((prev) => {
        if (Array.isArray(serverState.bazar)) {
          if (serverState.bazar.length === 0 && prev.length > 0) {
            setStateError((e) => e || 'সার্ভারে বাজারের তালিকা ফাঁকা পাওয়া গেছে। পূর্বের তথ্য অপরিবর্তিত রাখা হয়েছে।');
            return prev;
          }
          return serverState.bazar;
        }
        return prev;
      });

      setFixedExpenses((prev) => {
        if (Array.isArray(serverState.fixedExpenses)) {
          if (serverState.fixedExpenses.length === 0 && prev.length > 0) {
            setStateError((e) => e || 'সার্ভারে ফিক্সড খরচের তালিকা ফাঁকা পাওয়া গেছে। পূর্বের তথ্য অপরিবর্তিত রাখা হয়েছে।');
            return prev;
          }
          return serverState.fixedExpenses;
        }
        return prev;
      });

      if (serverState.settings) {
        setSettings(serverState.settings);
      }
      setLastUpdated(new Date());
    } catch (err: any) {
      console.info('State load from server failed:', err);
      // Keep old data, never overwrite screen with empty list!
      if (!isSilent) setStateError('সার্ভার থেকে তথ্য লোড করতে সমস্যা হয়েছে। পূর্বের তথ্য প্রদর্শিত হচ্ছে।');
    } finally {
      if (!isSilent) setIsStateLoading(false);
    }
  }, []);
  loadServerStateRef.current = loadServerStateImpl;

  // Last updated timestamp & Refresh handler for Header & Mobile (Item 6)
  const [lastUpdated, setLastUpdated] = useState<Date>(() => new Date());
  const [isGlobalRefreshing, setIsGlobalRefreshing] = useState<boolean>(false);

  const handleGlobalRefresh = useCallback(async () => {
    setIsGlobalRefreshing(true);
    try {
      await loadServerState();
      setLastUpdated(new Date());
    } finally {
      setIsGlobalRefreshing(false);
    }
  }, [loadServerState]);

  // Sync with Server Database on Initial Mount & Verify User Session
  useEffect(() => {
    // 1. Verify user session via httpOnly cookie
    verifySession();

    // 2. Health check to detect mock database (Item 2c)
    fetch('/api/health')
      .then((res) => res.json())
      .then((health) => {
        if (health && health.database === 'mock') {
          setIsMockDatabase(true);
        }
      })
      .catch(() => {});

    // 3. Load live state from server with Item 5 protection
    loadServerState();
  }, [verifySession, loadServerState]);

  // Update App Mode and Active Member based on verified user
  useEffect(() => {
    if (!authUser) {
      setActiveMemberId(null);
      return;
    }

    if (authUser.role === 'admin' || authUser.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
      setAppMode('admin');
      if (!activeMemberId) {
        setActiveMemberId('mem-1');
      }
    } else {
      setAppMode('member');
      // For a member, member id must come ONLY from server-verified session (memberId)
      if (authUser.memberId) {
        setActiveMemberId(authUser.memberId);
      } else {
        setActiveMemberId(null);
      }
    }
  }, [authUser]);

  // Real-time Monthly Accounting Calculation
  const monthlySummary = useMemo(() => {
    return calculateMonthlySummary(
      selectedMonth,
      members,
      meals,
      bazar,
      deposits,
      fixedExpenses,
      settings
    );
  }, [selectedMonth, members, meals, bazar, deposits, fixedExpenses, settings]);

  // Today's meals for badges and status
  const todayMeals = useMemo(() => {
    return meals.filter((m) => m.date === todayStr);
  }, [meals, todayStr]);

  const todayMealCount = useMemo(() => {
    return todayMeals.reduce((acc, m) => acc + (Number(m.mealCount) || 0), 0);
  }, [todayMeals]);

  // Admin Preview Member View
  const handlePreviewMember = (targetMemberId: string) => {
    setActiveMemberId(targetMemberId);
    navigate('/member/home');
  };

  // Quick Action trigger from Header
  const handleHeaderQuickAction = (action: 'meal' | 'deposit') => {
    if (action === 'meal') {
      navigate('/admin/meals');
    } else if (action === 'deposit') {
      setOpenQuickDeposit(true);
      navigate('/admin/deposits');
    }
  };

  // Save Day Meals (Admin)
  const handleSaveDayMeals = (
    date: string,
    mealEntries: { memberId: string; count: number; lunch?: boolean; dinner?: boolean }[]
  ) => {
    const otherMeals = meals.filter((m) => m.date !== date);
    const newRecords: MealRecord[] = mealEntries.map((entry) => ({
      id: `meal-${date}-${entry.memberId}`,
      date,
      memberId: entry.memberId,
      mealCount: entry.count,
      lunch: entry.lunch,
      dinner: entry.dinner,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }));

    const updated = [...otherMeals, ...newRecords];
    setMeals(updated);
    syncToServer({ meals: updated });
  };

  // Sync WhatsApp Poll votes to Mess Daily Meals for today
  const handleApplyPollToMeals = (slot: 'lunch' | 'dinner', votes: Record<string, PollVoteStatus>) => {
    const today = new Date().toISOString().split('T')[0];
    const existingTodayMeals = meals.filter((m) => m.date === today);
    const otherMeals = meals.filter((m) => m.date !== today);

    const updatedTodayRecords: MealRecord[] = members
      .filter((m) => m.isActive)
      .map((member) => {
        const existing = existingTodayMeals.find((m) => m.memberId === member.id);
        const vote = votes[member.id];
        const isYes = vote === 'YES' || vote === 'AUTO_YES';

        let currentLunch = existing ? (existing.lunch ?? (existing.mealCount >= 1)) : false;
        let currentDinner = existing ? (existing.dinner ?? (existing.mealCount >= 2)) : false;

        if (slot === 'lunch') {
          currentLunch = isYes;
        } else {
          currentDinner = isYes;
        }

        const mealCount = (currentLunch ? 1 : 0) + (currentDinner ? 1 : 0);

        return {
          id: existing ? existing.id : `meal-${today}-${member.id}`,
          date: today,
          memberId: member.id,
          mealCount,
          lunch: currentLunch,
          dinner: currentDinner,
          createdAt: existing ? existing.createdAt : new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
      });

    const updatedMeals = [...otherMeals, ...updatedTodayRecords];
    setMeals(updatedMeals);
    syncToServer({ meals: updatedMeals });
  };

  // Member CRUD with Total Deposit sync (Admin)
  const handleSaveMember = (member: Member, totalDepositAmount?: number) => {
    const exists = members.some((m) => m.id === member.id);
    let updated: Member[];
    if (exists) {
      updated = members.map((m) => (m.id === member.id ? member : m));
    } else {
      updated = [...members, member];
    }
    setMembers(updated);

    let updatedDeposits = deposits;
    if (totalDepositAmount !== undefined) {
      const currentMonthDeps = deposits.filter(
        (d) => d.memberId === member.id && d.date.startsWith(selectedMonth)
      );

      if (currentMonthDeps.length === 0) {
        if (totalDepositAmount > 0) {
          const newDep: Deposit = {
            id: `dep-${Date.now()}`,
            memberId: member.id,
            date: `${selectedMonth}-01`,
            amount: totalDepositAmount,
            paymentMethod: 'Cash',
            note: 'Total Deposit',
            createdAt: new Date().toISOString(),
          };
          updatedDeposits = [newDep, ...deposits];
        }
      } else if (currentMonthDeps.length === 1) {
        updatedDeposits = deposits.map((d) =>
          d.id === currentMonthDeps[0].id ? { ...d, amount: totalDepositAmount } : d
        );
      } else {
        const firstDepId = currentMonthDeps[0].id;
        const otherDepIds = new Set(currentMonthDeps.slice(1).map((d) => d.id));
        updatedDeposits = deposits
          .filter((d) => !otherDepIds.has(d.id))
          .map((d) => (d.id === firstDepId ? { ...d, amount: totalDepositAmount } : d));
      }
      setDeposits(updatedDeposits);
    }

    syncToServer({ members: updated, deposits: updatedDeposits });
  };

  const handleDeleteMember = (memberId: string) => {
    const updated = members.filter((m) => m.id !== memberId);
    setMembers(updated);

    const updatedMeals = meals.filter((m) => m.memberId !== memberId);
    setMeals(updatedMeals);

    const updatedDeposits = deposits.filter((d) => d.memberId !== memberId);
    setDeposits(updatedDeposits);

    syncToServer({ members: updated, meals: updatedMeals, deposits: updatedDeposits });
  };

  const handleToggleMemberActive = (memberId: string) => {
    const updated = members.map((m) =>
      m.id === memberId ? { ...m, isActive: !m.isActive } : m
    );
    setMembers(updated);
    syncToServer({ members: updated });
  };

  // Bazar CRUD
  const handleSaveBazar = (item: BazarExpense) => {
    const exists = bazar.some((b) => b.id === item.id);
    let updated: BazarExpense[];
    if (exists) {
      updated = bazar.map((b) => (b.id === item.id ? item : b));
    } else {
      updated = [item, ...bazar];
    }
    setBazar(updated);
    syncToServer({ bazar: updated });
  };

  const handleDeleteBazar = (id: string) => {
    const updated = bazar.filter((b) => b.id !== id);
    setBazar(updated);
    syncToServer({ bazar: updated });
  };

  // Deposit CRUD
  const handleSaveDeposit = (item: Deposit) => {
    const exists = deposits.some((d) => d.id === item.id);
    let updated: Deposit[];
    if (exists) {
      updated = deposits.map((d) => (d.id === item.id ? item : d));
    } else {
      updated = [item, ...deposits];
    }
    setDeposits(updated);
    syncToServer({ deposits: updated });
  };

  const handleDeleteDeposit = (id: string) => {
    const updated = deposits.filter((d) => d.id !== id);
    setDeposits(updated);
    syncToServer({ deposits: updated });
  };

  // Settings Save (Item 3a: server state is updated via PUT /api/mess/admin/settings, never syncToServer)
  const handleSaveSettings = (updated: MessSettings) => {
    setSettings(updated);
  };

  // Excel Import Completion
  const handleImportComplete = (imported: {
    members?: Member[];
    meals?: MealRecord[];
    bazar?: BazarExpense[];
    deposits?: Deposit[];
  }) => {
    if (imported.members) {
      setMembers(imported.members);
    }
    if (imported.meals) {
      setMeals(imported.meals);
    }
    if (imported.bazar) {
      setBazar(imported.bazar);
    }
    if (imported.deposits) {
      setDeposits(imported.deposits);
    }
    syncToServer(
      {
        members: imported.members || members,
        meals: imported.meals || meals,
        bazar: imported.bazar || bazar,
        deposits: imported.deposits || deposits,
      },
      { noDeletes: true }
    );
  };

  // Data cleared securely from Danger Zone (Item 4)
  const handleDataCleared = () => {
    setMembers([]);
    setMeals([]);
    setBazar([]);
    setDeposits([]);
    setFixedExpenses([]);
  };

  const navigate = useNavigate();

  // New Orders Count for Admin navigation badge (Section 1e)
  const [newOrdersCount, setNewOrdersCount] = useState<number>(0);

  const fetchOrdersCount = useCallback(async () => {
    if (!isAdmin) return;
    try {
      const res = await fetch('/api/mess/admin/orders/count', { credentials: 'include' });
      const json = await res.json();
      if (json.success && typeof json.count === 'number') {
        setNewOrdersCount(json.count);
      }
    } catch {
      // offline / mock
    }
  }, [isAdmin]);

  useEffect(() => {
    fetchOrdersCount();
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible') fetchOrdersCount();
    }, 60000);
    return () => clearInterval(interval);
  }, [fetchOrdersCount]);

  // Keep the admin panel up to date with what members do (new registrations, meal on/off).
  // Refreshes every minute while the tab is open, and right away when the tab is opened again.
  useEffect(() => {
    if (!isAdmin) return;
    const refresh = (force = false) => {
      if (document.visibilityState !== 'visible') return;
      if (pendingSyncCount.current > 0) return;
      if (!force && Date.now() - lastStateLoadRef.current < 10000) return;
      loadServerState(true);
    };
    const interval = setInterval(() => refresh(true), 60000);
    const onVisible = () => refresh(false);
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onVisible);
    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('focus', onVisible);
    };
  }, [isAdmin, loadServerState]);

  // Login Success Handler: navigates to ?redirect= or respective default panel
  const handleLoginSuccess = (user: AuthUser) => {
    setAuthUser(user);
    if (user.memberId) {
      setActiveMemberId(user.memberId);
    }
    try {
      localStorage.setItem('messmate_auth_user', JSON.stringify(user));
    } catch {}

    const params = new URLSearchParams(window.location.search);
    const redirect = params.get('redirect');
    const isUserAdmin = user.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase();

    if (redirect && redirect.startsWith('/') && !redirect.startsWith('//')) {
      navigate(redirect, { replace: true });
    } else if (isUserAdmin) {
      navigate('/admin/dashboard', { replace: true });
    } else {
      navigate('/member/home', { replace: true });
    }
  };

  // Logout Handler - Navigates directly to homepage ('/')
  const handleLogout = async () => {
    try {
      await ApiService.logout();
    } catch {}
    localStorage.removeItem('messmate_auth_user');
    sessionStorage.clear();
    setAuthUser(null);
    setActiveMemberId(null);
    navigate('/', { replace: true });
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  // If first admin login, forced password change screen can be completed or dismissed
  if (isAdmin && authUser?.mustChangePassword) {
    return (
      <AdminForcePasswordChange
        authUser={authUser}
        onPasswordChanged={(updatedUser) => {
          setAuthUser(updatedUser);
          try {
            localStorage.setItem('messmate_auth_user', JSON.stringify(updatedUser));
          } catch {}
        }}
        onDismiss={() => {
          const dismissedUser = { ...authUser, mustChangePassword: false };
          setAuthUser(dismissedUser);
          try {
            localStorage.setItem('messmate_auth_user', JSON.stringify(dismissedUser));
          } catch {}
        }}
        onLogout={handleLogout}
      />
    );
  }

  // If network connection error occurs and no user is authenticated, show retry screen
  if (connectionError && !authUser) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center p-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-stone-200 max-w-sm w-full text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center mx-auto">
            <WifiOff className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-stone-900">সংযোগে সমস্যা</h2>
            <p className="text-xs text-stone-600 mt-1">{connectionError}</p>
          </div>
          <button
            onClick={() => verifySession()}
            className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-sm transition-colors cursor-pointer"
          >
            আবার চেষ্টা করুন
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      {connectionError && authUser && (
        <div className="bg-amber-500 text-white px-4 py-2 text-xs font-bold flex items-center justify-between sticky top-0 z-50">
          <span>⚠️ {connectionError}</span>
          <button
            onClick={() => verifySession()}
            className="underline hover:text-stone-100 cursor-pointer ml-3 font-extrabold"
          >
            আবার চেষ্টা করুন
          </button>
        </div>
      )}
      {stateError && (
        <div className="bg-amber-600 text-white px-4 py-2.5 text-xs font-bold flex items-center justify-between shadow-md sticky top-0 z-50">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span>⚠️ {stateError}</span>
          </div>
          <button
            onClick={() => loadServerState()}
            disabled={isStateLoading}
            className="px-3 py-1 bg-white text-amber-950 rounded-lg font-black hover:bg-amber-100 transition-colors cursor-pointer shrink-0 ml-3"
          >
            {isStateLoading ? 'চেষ্টা হচ্ছে...' : 'পুনরায় চেষ্টা করুন'}
          </button>
        </div>
      )}
      {retryNotice && (
        <div className="fixed bottom-4 right-4 bg-slate-900/90 text-white text-xs px-4 py-2.5 rounded-xl shadow-lg z-50 flex items-center gap-2">
          <div className="h-3 w-3 rounded-full border-2 border-white border-t-transparent animate-spin" />
          <span>{retryNotice}</span>
        </div>
      )}
      <Suspense fallback={<RouteFallback />}>
<Routes>
        {/* ========================================== */}
        {/* PUBLIC ROUTES (Section 1a)                */}
        {/* ========================================== */}
        <Route path="/" element={<HomePage authUser={authUser} onLoginSuccess={handleLoginSuccess} />} />
        <Route path="/order" element={<OrderPage />} />
        <Route path="/order/status" element={<OrderStatusPage />} />
        <Route
          path="/login"
          element={
            <PublicLoginRoute
              authUser={authUser}
              isAdmin={isAdmin}
              authChecking={authChecking}
              onLoginSuccess={handleLoginSuccess}
            />
          }
        />
        <Route
          path="/register"
          element={
            <PublicRegisterRoute
              authUser={authUser}
              isAdmin={isAdmin}
              authChecking={authChecking}
              onRegisterSuccess={handleLoginSuccess}
            />
          }
        />

      {/* ========================================== */}
      {/* MEMBER ROUTES (Section 1a & 1c)           */}
      {/* ========================================== */}
      <Route
        path="/member/home"
        element={
          <RequireAuth authUser={authUser} authChecking={authChecking}>
            <div className="relative">
              {isAdmin && (
                <div className="bg-amber-600 text-white px-4 py-2 text-xs font-bold flex items-center justify-between shadow-xs sticky top-0 z-50">
                  <span>👑 আপনি এডমিন হিসেবে মেম্বার পোর্টাল প্রিভিউ দেখছেন</span>
                  <button
                    onClick={() => navigate('/admin/dashboard')}
                    className="px-3 py-1 bg-white text-amber-900 rounded-lg font-black hover:bg-amber-50 transition-colors cursor-pointer"
                  >
                    এডমিন প্যানেলে ফিরুন
                  </button>
                </div>
              )}
              <MemberPortalView
                memberId={
                  isAdmin
                    ? (activeMemberId || 'mem-1')
                    : (authUser?.memberId || authUser?.id || activeMemberId || 'me')
                }
                onLogout={handleLogout}
                isAdmin={isAdmin}
                authUser={authUser}
                onOpenAdminLogin={() => {
                  if (isAdmin) navigate('/admin/dashboard');
                  else handleLogout();
                }}
                allMembersFallback={members}
                allMealsFallback={meals}
                allDepositsFallback={deposits}
                allBazarFallback={bazar}
                settingsFallback={settings}
                onRefresh={handleGlobalRefresh}
                lastUpdated={lastUpdated}
                isRefreshing={isGlobalRefreshing}
              />
            </div>
          </RequireAuth>
        }
      />
      <Route
        path="/member/meal"
        element={
          <RequireAuth authUser={authUser} authChecking={authChecking}>
            <MemberMealPage
              authUser={authUser}
              onLogout={handleLogout}
              onRefresh={handleGlobalRefresh}
              lastUpdated={lastUpdated}
              isRefreshing={isGlobalRefreshing}
            />
          </RequireAuth>
        }
      />
      <Route
        path="/member/history"
        element={
          <RequireAuth authUser={authUser} authChecking={authChecking}>
            <MemberHistoryPage
              authUser={authUser}
              onLogout={handleLogout}
              isAdmin={isAdmin}
              onRefresh={handleGlobalRefresh}
              lastUpdated={lastUpdated}
              isRefreshing={isGlobalRefreshing}
            />
          </RequireAuth>
        }
      />
      <Route
        path="/member/payment"
        element={
          <RequireAuth authUser={authUser} authChecking={authChecking}>
            <MemberPaymentPage
              authUser={authUser}
              onLogout={handleLogout}
              isAdmin={isAdmin}
              onRefresh={handleGlobalRefresh}
              lastUpdated={lastUpdated}
              isRefreshing={isGlobalRefreshing}
            />
          </RequireAuth>
        }
      />
      <Route
        path="/member/complaints"
        element={
          <RequireAuth authUser={authUser} authChecking={authChecking}>
            <MemberComplaintsPage
              authUser={authUser}
              onLogout={handleLogout}
              isAdmin={isAdmin}
              onRefresh={handleGlobalRefresh}
              lastUpdated={lastUpdated}
              isRefreshing={isGlobalRefreshing}
            />
          </RequireAuth>
        }
      />
      <Route
        path="/member/profile"
        element={
          <RequireAuth authUser={authUser} authChecking={authChecking}>
            <MemberProfilePage
              authUser={authUser}
              onLogout={handleLogout}
              isAdmin={isAdmin}
              onRefresh={handleGlobalRefresh}
              lastUpdated={lastUpdated}
              isRefreshing={isGlobalRefreshing}
            />
          </RequireAuth>
        }
      />
      <Route path="/member" element={<Navigate to="/member/home" replace />} />

      {/* ========================================== */}
      {/* ADMIN ROUTES (Section 1a, 1c & 1e)        */}
      {/* ========================================== */}
      <Route
        path="/admin/*"
        element={
          <RequireAdmin authUser={authUser} isAdmin={isAdmin} authChecking={authChecking}>
            <div className="flex h-screen w-screen overflow-hidden bg-slate-100/70 text-slate-900 font-sans">
              {/* Desktop Left Sidebar */}
              <Sidebar
                settings={settings}
                todayMealCount={todayMealCount}
                memberCount={members.length}
                newOrdersCount={newOrdersCount}
                onOpenShareLinks={() => setIsShareModalOpen(true)}
                onSwitchToMemberView={() => {
                  setActiveMemberId(activeMemberId || 'mem-1');
                  navigate('/member/home');
                }}
                authUser={authUser}
                onLogout={handleLogout}
              />

              {/* Main Content Area */}
              <div className="flex-1 flex flex-col h-full overflow-hidden">
                {isMockDatabase && (
                  <div className="bg-red-600 text-white px-4 py-2 text-xs font-bold flex items-center justify-center gap-2 shadow-sm shrink-0">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>ডেটাবেস অস্থায়ী: রিস্টার্টে সব ডেটা ও লগইন মুছে যাবে</span>
                  </div>
                )}
                {/* Sticky Top Header */}
                <Header
                  selectedMonth={selectedMonth}
                  onSelectMonth={setSelectedMonth}
                  settings={settings}
                  onOpenQuickAction={handleHeaderQuickAction}
                  onNavigateTab={(tab) => navigate(`/admin/${tab}`)}
                  onOpenShareLinks={() => setIsShareModalOpen(true)}
                  onSwitchToMemberView={() => {
                    setActiveMemberId(activeMemberId || 'mem-1');
                    navigate('/member/home');
                  }}
                  authUser={authUser}
                  onLogout={handleLogout}
                  onRefresh={handleGlobalRefresh}
                  lastUpdated={lastUpdated}
                  isRefreshing={isGlobalRefreshing}
                />

                {/* Scrollable View Container with PullToRefresh */}
                <main className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 pt-6 pb-28 lg:pb-8">
                  <PullToRefresh onRefresh={handleGlobalRefresh}>
                    <div className="max-w-7xl mx-auto">
                      <Suspense fallback={<RouteFallback />}>
<Routes>
                      <Route
                        path="dashboard"
                        element={
                          <DashboardView
                            summary={monthlySummary}
                            members={members}
                            todayMeals={todayMeals}
                            allMeals={meals}
                            allDeposits={deposits}
                            settings={settings}
                            onNavigateTab={(tab) => navigate(`/admin/${tab}`)}
                            onOpenQuickAction={handleHeaderQuickAction}
                          />
                        }
                      />
                      <Route
                        path="meals"
                        element={
                          <MealEntryView
                            members={members}
                            allMeals={meals}
                            onSaveDayMeals={handleSaveDayMeals}
                            settings={settings}
                            onNavigateTab={(tab) => navigate(`/admin/${tab}`)}
                          />
                        }
                      />
                      <Route
                        path="members"
                        element={
                          <MembersView
                            members={members}
                            onSaveMember={handleSaveMember}
                            onDeleteMember={handleDeleteMember}
                            onToggleActive={handleToggleMemberActive}
                            meals={meals}
                            deposits={deposits}
                            summary={monthlySummary}
                            settings={settings}
                          />
                        }
                      />
                      <Route
                        path="bazar"
                        element={
                          <BazarView
                            bazar={bazar}
                            members={members}
                            onSaveBazar={handleSaveBazar}
                            onDeleteBazar={handleDeleteBazar}
                            selectedMonth={selectedMonth}
                            settings={settings}
                          />
                        }
                      />
                      <Route
                        path="deposits"
                        element={
                          <DepositsView
                            deposits={deposits}
                            members={members}
                            onSaveDeposit={handleSaveDeposit}
                            onDeleteDeposit={handleDeleteDeposit}
                            selectedMonth={selectedMonth}
                            settings={settings}
                            isOpenAddModalDirectly={openQuickDeposit}
                            onCloseAddModalDirectly={() => setOpenQuickDeposit(false)}
                          />
                        }
                      />
                      <Route
                        path="orders"
                        element={<OrdersView />}
                      />
                      <Route
                        path="whatsapp"
                        element={
                          <WhatsAppPollView
                            members={members}
                            settings={settings}
                            onUpdateSettings={handleSaveSettings}
                            onApplyPollToMeals={handleApplyPollToMeals}
                          />
                        }
                      />
                      <Route
                        path="settings"
                        element={
                          <SettingsView
                            settings={settings}
                            onSaveSettings={handleSaveSettings}
                            members={members}
                            meals={meals}
                            bazar={bazar}
                            deposits={deposits}
                            onImportComplete={handleImportComplete}
                            onDataCleared={handleDataCleared}
                          />
                        }
                      />
                      <Route path="*" element={<Navigate to="/admin/dashboard" replace />} />
                    </Routes>
</Suspense>
                  </div>
                  </PullToRefresh>
                </main>

                {/* Mobile Bottom Navigation Bar */}
                <BottomNav
                  todayMealCount={todayMealCount}
                  memberCount={members.length}
                  newOrdersCount={newOrdersCount}
                  settings={settings}
                  onLogout={handleLogout}
                  onRefresh={handleGlobalRefresh}
                  lastUpdated={lastUpdated}
                  isRefreshing={isGlobalRefreshing}
                />
              </div>

              {/* Share Links Modal */}
              <ShareLinksModal
                isOpen={isShareModalOpen}
                onClose={() => setIsShareModalOpen(false)}
                members={members}
                settings={settings}
                onPreviewMember={(memberId) => {
                  setIsShareModalOpen(false);
                  setActiveMemberId(memberId);
                  navigate('/member/home');
                }}
              />
            </div>
          </RequireAdmin>
        }
      />

      {/* ========================================== */}
      {/* 404 NOT FOUND ROUTE                       */}
      {/* ========================================== */}
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
</Suspense>
  </>
);
}

// ---------------------------------------------------------------------------
// ROUTE GUARDS (Section 1c)
// ---------------------------------------------------------------------------

function RequireAuth({
  authUser,
  authChecking,
  children,
}: {
  authUser: AuthUser | null;
  authChecking?: boolean;
  children: React.ReactElement;
}) {
  if (authChecking) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center p-4">
        <div className="flex flex-col items-center gap-3">
          <div className="h-9 w-9 rounded-full border-4 border-emerald-600 border-t-transparent animate-spin" />
          <p className="text-xs font-bold text-slate-500">লোড হচ্ছে...</p>
        </div>
      </div>
    );
  }
  if (!authUser) {
    return <Navigate to="/" replace />;
  }
  // For a member, memberId must come only from the server-verified session. If missing, show login page.
  const isAdminUser = authUser.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase();
  if (!isAdminUser && !authUser.memberId) {
    return <Navigate to="/" replace />;
  }
  return children;
}

function RequireAdmin({
  authUser,
  isAdmin,
  authChecking,
  children,
}: {
  authUser: AuthUser | null;
  isAdmin: boolean;
  authChecking?: boolean;
  children: React.ReactElement;
}) {
  if (authChecking) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center p-4">
        <div className="flex flex-col items-center gap-3">
          <div className="h-9 w-9 rounded-full border-4 border-emerald-600 border-t-transparent animate-spin" />
          <p className="text-xs font-bold text-slate-500">লোড হচ্ছে...</p>
        </div>
      </div>
    );
  }
  if (!authUser) {
    return <Navigate to="/" replace />;
  }
  if (!isAdmin) {
    return <Navigate to="/member/home" replace />;
  }
  return children;
}

function PublicLoginRoute({
  authUser,
  isAdmin,
  authChecking,
  onLoginSuccess,
}: {
  authUser: AuthUser | null;
  isAdmin: boolean;
  authChecking?: boolean;
  onLoginSuccess: (user: AuthUser) => void;
}) {
  const [searchParams] = useSearchParams();
  const redirect = searchParams.get('redirect');

  if (authChecking) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center p-4">
        <div className="flex flex-col items-center gap-3">
          <div className="h-9 w-9 rounded-full border-4 border-emerald-600 border-t-transparent animate-spin" />
          <p className="text-xs font-bold text-slate-500">লোড হচ্ছে...</p>
        </div>
      </div>
    );
  }

  if (authUser) {
    if (redirect && redirect.startsWith('/') && !redirect.startsWith('//')) {
      return <Navigate to={redirect} replace />;
    }
    return <Navigate to={isAdmin ? '/admin/dashboard' : '/member/home'} replace />;
  }

  return <LoginView onLoginSuccess={onLoginSuccess} />;
}

function PublicRegisterRoute({
  authUser,
  isAdmin,
  authChecking,
  onRegisterSuccess,
}: {
  authUser: AuthUser | null;
  isAdmin: boolean;
  authChecking?: boolean;
  onRegisterSuccess: (user: AuthUser) => void;
}) {
  if (authChecking) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center p-4">
        <div className="flex flex-col items-center gap-3">
          <div className="h-9 w-9 rounded-full border-4 border-emerald-600 border-t-transparent animate-spin" />
          <p className="text-xs font-bold text-slate-500">লোড হচ্ছে...</p>
        </div>
      </div>
    );
  }

  if (authUser) {
    return <Navigate to={isAdmin ? '/admin/dashboard' : '/member/home'} replace />;
  }
  return <RegisterPage onRegisterSuccess={onRegisterSuccess} />;
}

