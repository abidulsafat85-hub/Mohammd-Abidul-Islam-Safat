import React, { useState, useRef } from 'react';
import {
  Settings as SettingsIcon,
  Save,
  Download,
  Upload,
  FileSpreadsheet,
  Trash2,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  FileUp,
  Sliders,
  DollarSign,
  Lock,
  Eye,
  EyeOff,
  Image as ImageIcon,
  X,
} from 'lucide-react';
import { MessSettings, MealRateMode, Member, MealRecord, BazarExpense, Deposit, FixedExpense } from '../../types';
import { StorageService } from '../../services/storage';
import { ExcelService, ImportPreviewData } from '../../services/excelService';
import { ApiService } from '../../services/apiService';
import { Modal } from '../common/Modal';
import { useBranding } from '../../hooks/useBranding';

interface SettingsViewProps {
  settings: MessSettings;
  onSaveSettings: (settings: MessSettings) => void;
  members: Member[];
  meals: MealRecord[];
  bazar: BazarExpense[];
  deposits: Deposit[];
  onImportComplete: (data: {
    members?: Member[];
    meals?: MealRecord[];
    bazar?: BazarExpense[];
    deposits?: Deposit[];
  }) => void;
  onDataCleared: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onSaveSettings,
  members,
  meals,
  bazar,
  deposits,
  onImportComplete,
  onDataCleared,
}) => {
  // Danger Zone state (Item 4)
  const [dangerConfirmWord, setDangerConfirmWord] = useState('');
  const [dangerPassword, setDangerPassword] = useState('');
  const [dangerLoading, setDangerLoading] = useState(false);
  const [dangerError, setDangerError] = useState<string | null>(null);
  const [dangerSuccess, setDangerSuccess] = useState<string | null>(null);

  // Central Branding state from hook
  const { appName: currentAppName, logo: currentLogo, setBranding } = useBranding();
  const [appName, setAppName] = useState(currentAppName || 'MessMate');
  const [logoPreview, setLogoPreview] = useState<string | undefined>(currentLogo);
  const [brandingLoading, setBrandingLoading] = useState(false);
  const [brandingError, setBrandingError] = useState<string | null>(null);
  const [brandingSuccess, setBrandingSuccess] = useState<string | null>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  // Form states
  const [messName, setMessName] = useState(settings.messName || currentAppName || 'MessMate');
  const [currency] = useState(settings.currency);
  const [fixedMealRate, setFixedMealRate] = useState<string>(
    settings.fixedMealRate !== undefined && settings.fixedMealRate !== null ? String(settings.fixedMealRate) : ''
  );
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [settingsLoading, setSettingsLoading] = useState(false);
  const [settingsError, setSettingsError] = useState<string | null>(null);

  // Sync inputs when server settings update
  React.useEffect(() => {
    if (settings) {
      if (settings.messName) setMessName(settings.messName);
      if (settings.fixedMealRate !== undefined && settings.fixedMealRate !== null) {
        setFixedMealRate(String(settings.fixedMealRate));
      }
    }
  }, [settings]);

  // Excel Import states
  const [importPreview, setImportPreview] = useState<ImportPreviewData | null>(null);
  const [importMode, setImportMode] = useState<'append' | 'replace'>('append');
  const [isImporting, setIsImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const jsonRestoreInputRef = useRef<HTMLInputElement>(null);

  // Admin Change Password states
  const [currentAdminPassword, setCurrentAdminPassword] = useState('');
  const [newAdminPassword, setNewAdminPassword] = useState('');
  const [confirmAdminPassword, setConfirmAdminPassword] = useState('');
  const [showAdminPass, setShowAdminPass] = useState(false);
  const [adminPassLoading, setAdminPassLoading] = useState(false);
  const [adminPassError, setAdminPassError] = useState<string | null>(null);
  const [adminPassSuccess, setAdminPassSuccess] = useState<string | null>(null);

  const handleAdminChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminPassError(null);
    setAdminPassSuccess(null);

    const currentTrimmed = currentAdminPassword.trim();
    const newTrimmed = newAdminPassword.trim();
    const confirmTrimmed = confirmAdminPassword.trim();

    if (!currentTrimmed) {
      setAdminPassError('বর্তমান পাসওয়ার্ড দেওয়া আবশ্যক (Current password is required)');
      return;
    }

    if (newTrimmed.length < 8) {
      setAdminPassError('নতুন পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে (At least 8 characters required)');
      return;
    }

    if (newTrimmed === '12345') {
      setAdminPassError("নতুন পাসওয়ার্ড '12345' হওয়া যাবে না");
      return;
    }

    if (newTrimmed !== confirmTrimmed) {
      setAdminPassError('কনফার্ম পাসওয়ার্ডের সাথে নতুন পাসওয়ার্ডের মিল নেই');
      return;
    }

    setAdminPassLoading(true);
    try {
      const res = await ApiService.adminChangePassword(currentTrimmed, newTrimmed);
      if (res.success) {
        setAdminPassSuccess('এডমিন পাসওয়ার্ড সফলভাবে আপডেট করা হয়েছে!');
        setCurrentAdminPassword('');
        setNewAdminPassword('');
        setConfirmAdminPassword('');
      } else {
        setAdminPassError(res.message || 'পাসওয়ার্ড পরিবর্তন ব্যর্থ হয়েছে');
      }
    } catch (err: any) {
      setAdminPassError(err?.message || 'পাসওয়ার্ড পরিবর্তন ব্যর্থ হয়েছে');
    } finally {
      setAdminPassLoading(false);
    }
  };

  // Save Settings via PUT /api/mess/admin/settings (Item 3)
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsError(null);
    setSaveMessage(null);

    const trimmedRate = fixedMealRate.trim();
    const rateNum = Number(trimmedRate);
    const usesMealRate = settings.mealRateMode !== 'bazar_only';

    // If empty or <= 0: rate of 0 is only allowed when mealRateMode does not use it
    if (trimmedRate === '') {
      if (usesMealRate) {
        setSettingsError('মীল রেট ০ এর বেশি হতে হবে');
        return;
      }
    } else {
      if (isNaN(rateNum) || (rateNum <= 0 && usesMealRate)) {
        setSettingsError('মীল রেট ০ এর বেশি হতে হবে');
        return;
      }
      if (rateNum < 0) {
        setSettingsError('মীল রেট ০ এর বেশি হতে হবে');
        return;
      }
    }

    const payload: Partial<MessSettings> = {
      messName: messName.trim() || 'MessMate',
      currency: currency.trim() || '৳',
      fixedMealRate: trimmedRate === '' ? 0 : rateNum,
    };

    setSettingsLoading(true);
    try {
      const serverUpdated = await ApiService.updateSettings(payload);
      onSaveSettings(serverUpdated);
      setFixedMealRate(String(serverUpdated.fixedMealRate ?? 0));
      setSaveMessage('সেটিংস সফলভাবে সংরক্ষিত হয়েছে!');
      setTimeout(() => setSaveMessage(null), 3500);
    } catch (err: any) {
      setSettingsError(err?.message || 'সেটিংস সংরক্ষণ ব্যর্থ হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
    } finally {
      setSettingsLoading(false);
    }
  };

  // Download Backup JSON
  const handleBackupDownload = () => {
    const jsonStr = StorageService.createBackupFromState({
      members,
      meals,
      bazar,
      deposits,
      settings,
    });
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const safeName = (appName || 'Ghorer_Shadh').replace(/\s+/g, '_');
    link.download = `${safeName}_Backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle Danger Zone Clear Data (Item 4: downloads backup first, requires "মুছুন" and password, logs audit)
  const handleDangerClearData = async (e: React.FormEvent) => {
    e.preventDefault();
    setDangerError(null);
    setDangerSuccess(null);

    if (dangerConfirmWord.trim() !== 'মুছুন') {
      setDangerError('নিশ্চিতকরণ শব্দ ভুল! অনুগ্রহ করে ঠিক "মুছুন" শব্দটি লিখুন।');
      return;
    }

    if (!dangerPassword.trim()) {
      setDangerError('এডমিন পাসওয়ার্ড দেওয়া আবশ্যক।');
      return;
    }

    // 1. Download backup first
    handleBackupDownload();

    // 2. Call server endpoint
    setDangerLoading(true);
    try {
      const res = await ApiService.dangerClearData('মুছুন', dangerPassword.trim());
      if (res.success) {
        setDangerSuccess('সমস্ত তথ্য সফলভাবে মুছে ফেলা হয়েছে এবং ব্যাকআপ ফাইল ডাউনলোড হয়েছে।');
        setDangerConfirmWord('');
        setDangerPassword('');
        onDataCleared();
      } else {
        setDangerError(res.message || 'ডেটা মুছা সম্ভব হয়নি।');
      }
    } catch (err: any) {
      setDangerError(err?.message || 'ডেটা মুছতে ত্রুটি হয়েছে। এডমিন পাসওয়ার্ড পুনরায় পরীক্ষা করুন।');
    } finally {
      setDangerLoading(false);
    }
  };

  // Handle Restore JSON
  const handleRestoreFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const result = StorageService.restoreBackup(content);
        if (result.success) {
          alert('Backup restored successfully! The page will now reload.');
          window.location.reload();
        } else {
          alert(`Restore failed: ${result.message}`);
        }
      }
    };
    reader.readAsText(file);
  };

  // Handle Excel File Selected for Import
  const handleExcelFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsImporting(true);
      const preview = await ExcelService.parseExcelFile(file, members);
      setImportPreview(preview);
    } catch (err) {
      alert(`Error reading spreadsheet: ${(err as Error).message}`);
    } finally {
      setIsImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Confirm Excel Import
  const handleConfirmImport = () => {
    if (!importPreview) return;

    const newMembers: Member[] = (importPreview.members as Member[]) || [];
    const newMeals: MealRecord[] = (importPreview.meals as MealRecord[]) || [];
    const newBazar: BazarExpense[] = (importPreview.bazar as BazarExpense[]) || [];
    const newDeposits: Deposit[] = (importPreview.deposits as Deposit[]) || [];

    if (importMode === 'replace') {
      onImportComplete({
        members: newMembers,
        meals: newMeals,
        bazar: newBazar,
        deposits: newDeposits,
      });
    } else {
      // Append mode: merge avoiding duplicates
      const mergedMembers = [...members];
      newMembers.forEach((nm) => {
        if (!mergedMembers.some((m) => m.fullName.toLowerCase() === nm.fullName.toLowerCase())) {
          mergedMembers.push(nm);
        }
      });

      const mergedMeals = [...meals, ...newMeals];
      const mergedBazar = [...bazar, ...newBazar];
      const mergedDeposits = [...deposits, ...newDeposits];

      onImportComplete({
        members: mergedMembers,
        meals: mergedMeals,
        bazar: mergedBazar,
        deposits: mergedDeposits,
      });
    }

    setImportPreview(null);
    alert('Import completed successfully!');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20">
      {/* Title */}
      <div>
        <h2 className="text-2xl font-black text-slate-900 tracking-tight">System Settings</h2>
        <p className="text-xs sm:text-sm text-slate-500">
          Configure mess parameters, calculation rules, backup database, and import Excel data.
        </p>
      </div>

      {saveMessage && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-sm font-bold flex items-center gap-2">
          <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0" />
          <span>{saveMessage}</span>
        </div>
      )}

      {settingsError && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-sm font-bold flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-rose-600 shrink-0" />
          <span>{settingsError}</span>
        </div>
      )}

      {/* Main Configuration Form */}
      <form onSubmit={handleSave} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs space-y-6">
        <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
          <Sliders className="h-5 w-5 text-emerald-600" />
          <h3 className="font-extrabold text-slate-900 text-lg">সাধারণ ও মেস তথ্য (General & Mess Info)</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              মেসের নাম (Mess Name) <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              id="settings-messname"
              value={messName}
              onChange={(e) => {
                setMessName(e.target.value);
                setSettingsError(null);
              }}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              মীল রেট (Meal Rate - {currency})
            </label>
            <input
              type="number"
              id="settings-meal-rate"
              value={fixedMealRate}
              onChange={(e) => {
                setFixedMealRate(e.target.value);
                setSettingsError(null);
              }}
              min="0"
              step="any"
              placeholder="যেমন: ৫০"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bold"
            />
            <div className="text-[11px] text-slate-500 mt-1.5 leading-relaxed bg-slate-50 p-2.5 rounded-xl border border-slate-100">
              <span className="font-bold text-slate-700 block mb-0.5">💡 মীল রেটের ব্যবহার:</span>
              <span>
                এটি ফিক্সড বা ফলব্যাক রেট হিসেবে ব্যবহৃত হয় (বাজার খরচ ছাড়া নির্ধারিত মিল রেট)।
              </span>
              {settings.mealRateMode === 'bazar_only' ? (
                <span className="text-emerald-700 font-bold block mt-0.5">
                  • বর্তমান মোড: 'বাজার ভিত্তিক' — বাজার খরচের অনুপাতে রেট বের হয়, তাই এই মোডে ০ রাখা যাবে।
                </span>
              ) : (
                <span className="text-amber-700 font-bold block mt-0.5">
                  • বর্তমান মোড: 'ফিক্সড/অন্যান্য' — এখানে মিল রেট অবশ্যই ০ এর বেশি হতে হবে।
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="pt-4 flex justify-end">
          <button
            type="submit"
            id="btn-save-settings-submit"
            disabled={settingsLoading}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-extrabold text-sm shadow-sm transition-all cursor-pointer"
          >
            {settingsLoading ? (
              <div className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
            ) : (
              <Save className="h-4 w-4" />
            )}
            <span>{settingsLoading ? 'সংরক্ষণ হচ্ছে...' : 'সেটিংস সেভ করুন'}</span>
          </button>
        </div>
      </form>

      {/* Admin Password & Security Section (Requirement 5) */}
      <form onSubmit={handleAdminChangePassword} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <Lock className="h-5 w-5 text-indigo-600" />
            <div>
              <h3 className="font-extrabold text-slate-900 text-lg">এডমিন পাসওয়ার্ড পরিবর্তন (Change Admin Password)</h3>
              <p className="text-xs text-slate-500">আপনার এডমিন একাউন্টের বর্তমান পাসওয়ার্ড দিয়ে নতুন পাসওয়ার্ড সেট করুন।</p>
            </div>
          </div>
        </div>

        {adminPassSuccess && (
          <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
            <span>{adminPassSuccess}</span>
          </div>
        )}

        {adminPassError && (
          <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0" />
            <span>{adminPassError}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              বর্তমান পাসওয়ার্ড <span className="text-rose-500">*</span>
            </label>
            <input
              type={showAdminPass ? 'text' : 'password'}
              required
              value={currentAdminPassword}
              onChange={(e) => {
                setCurrentAdminPassword(e.target.value);
                setAdminPassError(null);
              }}
              placeholder="বর্তমান পাসওয়ার্ড লিখুন"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              নতুন পাসওয়ার্ড (কমপক্ষে ৮ অক্ষর) <span className="text-rose-500">*</span>
            </label>
            <input
              type={showAdminPass ? 'text' : 'password'}
              required
              minLength={8}
              value={newAdminPassword}
              onChange={(e) => {
                setNewAdminPassword(e.target.value);
                setAdminPassError(null);
              }}
              placeholder="কমপক্ষে ৮ অক্ষর"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              নতুন পাসওয়ার্ড নিশ্চিত করুন <span className="text-rose-500">*</span>
            </label>
            <input
              type={showAdminPass ? 'text' : 'password'}
              required
              minLength={8}
              value={confirmAdminPassword}
              onChange={(e) => {
                setConfirmAdminPassword(e.target.value);
                setAdminPassError(null);
              }}
              placeholder="পুনরায় পাসওয়ার্ড লিখুন"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none font-mono"
            />
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            onClick={() => setShowAdminPass(!showAdminPass)}
            className="text-xs font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1.5 cursor-pointer"
          >
            {showAdminPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            <span>{showAdminPass ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}</span>
          </button>

          <button
            type="submit"
            disabled={adminPassLoading}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs shadow-sm transition-all cursor-pointer disabled:opacity-50"
          >
            <Lock className="h-3.5 w-3.5" />
            <span>{adminPassLoading ? 'আপডেট হচ্ছে...' : 'পাসওয়ার্ড পরিবর্তন করুন'}</span>
          </button>
        </div>
      </form>

      {/* Excel Import & Template Section */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs space-y-6">
        <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
          <FileSpreadsheet className="h-5 w-5 text-teal-600" />
          <h3 className="font-extrabold text-slate-900 text-lg">Excel Spreadsheet Import & Templates</h3>
        </div>

        <p className="text-xs sm:text-sm text-slate-600">
          Import your existing mess Excel workbook (.xlsx, .xls, .csv). The smart parser extracts Members, Meals, Bazar expenses, and Deposits with preview verification before saving.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Upload Excel Card */}
          <div className="p-5 rounded-2xl border border-dashed border-emerald-300 bg-emerald-50/40 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-emerald-800 font-extrabold text-sm">
                <FileUp className="h-5 w-5 text-emerald-600" />
                <span>Upload Excel File</span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Select an Excel spreadsheet to auto-import historical meals, bazar, and member records.
              </p>
            </div>

            <div className="mt-4">
              <input
                type="file"
                ref={fileInputRef}
                accept=".xlsx,.xls,.csv"
                onChange={handleExcelFileSelect}
                className="hidden"
                id="excel-import-file-input"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isImporting}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm text-center shadow-xs transition-colors cursor-pointer"
              >
                {isImporting ? 'Parsing Excel...' : 'Choose Excel File (.xlsx)'}
              </button>
            </div>
          </div>

          {/* Download Template Card */}
          <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/70 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-slate-800 font-extrabold text-sm">
                <Download className="h-5 w-5 text-slate-600" />
                <span>Download Sample Template</span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Get a pre-formatted Excel workbook template formatted with Members, Meals, Bazar, and Deposits sheets.
              </p>
            </div>

            <div className="mt-4">
              <button
                type="button"
                id="btn-download-excel-template"
                onClick={() => ExcelService.downloadTemplate()}
                className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 font-bold text-xs sm:text-sm text-center shadow-xs transition-colors cursor-pointer"
              >
                Download Template (.xlsx)
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Backup & Restore Section */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs space-y-6">
        <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
          <Download className="h-5 w-5 text-blue-600" />
          <h3 className="font-extrabold text-slate-900 text-lg">Backup & Restore Offline Database</h3>
        </div>

        <p className="text-xs sm:text-sm text-slate-600">
          Save an offline copy of your entire mess database or restore from a previous JSON backup file anytime.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            type="button"
            id="btn-backup-json"
            onClick={handleBackupDownload}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs sm:text-sm border border-slate-200 transition-colors cursor-pointer"
          >
            <Download className="h-4 w-4 text-emerald-600" />
            <span>Download Database Backup (JSON)</span>
          </button>

          <div>
            <input
              type="file"
              ref={jsonRestoreInputRef}
              accept=".json"
              onChange={handleRestoreFileSelect}
              className="hidden"
              id="json-restore-file-input"
            />
            <button
              type="button"
              id="btn-restore-json"
              onClick={() => jsonRestoreInputRef.current?.click()}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs sm:text-sm border border-slate-200 transition-colors cursor-pointer"
            >
              <Upload className="h-4 w-4 text-blue-600" />
              <span>Restore Database from File</span>
            </button>
          </div>
        </div>
      </div>

      {/* Danger Zone: Clear Data (Item 4: requires "মুছুন", password, backup, and audit log) */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-rose-300 shadow-xs space-y-5">
        <div className="flex items-center gap-2.5 text-rose-700 font-extrabold text-lg pb-3 border-b border-rose-100">
          <AlertTriangle className="h-6 w-6 text-rose-600 shrink-0" />
          <span>ডেঞ্জার জোন (Danger Zone - ডেটা মুছে ফেলা)</span>
        </div>

        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
          সমস্ত মেম্বার, মিল, বাজার এবং জমা হিসাব স্থায়ীভাবে মুছে ফেলতে হলে নিচের শর্তগুলো পূরণ করুন। এই পদক্ষেপটি নেয়ার আগে <strong>স্বয়ংক্রিয়ভাবে একটি অফলাইন ব্যাকআপ ফাইল ডাউনলোড হবে</strong> এবং সার্ভারে অডিট লগ এন্ট্রি সংরক্ষিত হবে।
        </p>

        {dangerSuccess && (
          <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
            <span>{dangerSuccess}</span>
          </div>
        )}

        {dangerError && (
          <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0" />
            <span>{dangerError}</span>
          </div>
        )}

        <form onSubmit={handleDangerClearData} className="space-y-4 pt-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                নিশ্চিতকরণ শব্দ টাইপ করুন: <span className="text-rose-600 font-extrabold">মুছুন</span>
              </label>
              <input
                type="text"
                id="input-danger-confirm-word"
                value={dangerConfirmWord}
                onChange={(e) => {
                  setDangerConfirmWord(e.target.value);
                  setDangerError(null);
                }}
                placeholder='এখানে "মুছুন" লিখুন'
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                এডমিন পাসওয়ার্ড (Admin Password)
              </label>
              <input
                type="password"
                id="input-danger-admin-password"
                value={dangerPassword}
                onChange={(e) => {
                  setDangerPassword(e.target.value);
                  setDangerError(null);
                }}
                placeholder="আপনার এডমিন পাসওয়ার্ড লিখুন"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none font-mono"
                required
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              id="btn-danger-clear-submit"
              disabled={dangerLoading || dangerConfirmWord.trim() !== 'মুছুন' || !dangerPassword.trim()}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-extrabold text-xs sm:text-sm shadow-sm transition-all cursor-pointer"
            >
              {dangerLoading ? (
                <div className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
              ) : (
                <Trash2 className="h-4 w-4" />
              )}
              <span>{dangerLoading ? 'প্রসেস হচ্ছে...' : 'ব্যাকআপ ডাউনলোড ও সমস্ত ডেটা মুছুন'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Excel Import Preview Modal */}
      {importPreview && (
        <Modal
          isOpen={!!importPreview}
          onClose={() => setImportPreview(null)}
          title="Spreadsheet Import Preview"
          subtitle="Confirm detected spreadsheet records before applying"
          maxWidth="lg"
        >
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-950 font-bold text-sm">
              {importPreview.summaryText}
            </div>

            <div className="space-y-2 text-xs text-slate-600">
              <label className="font-bold text-slate-800 block">Import Mode:</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setImportMode('append')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    importMode === 'append'
                      ? 'bg-emerald-50 border-emerald-500 font-bold text-emerald-950'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div>Append / Merge</div>
                  <div className="text-[11px] text-slate-400 font-normal mt-0.5">
                    Preserves current records and adds newly detected ones.
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setImportMode('replace')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    importMode === 'replace'
                      ? 'bg-rose-50 border-rose-500 font-bold text-rose-950'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div>Replace Existing</div>
                  <div className="text-[11px] text-slate-400 font-normal mt-0.5">
                    Clears existing data and replaces with this spreadsheet.
                  </div>
                </button>
              </div>
            </div>

            <div className="pt-4 flex items-center justify-end gap-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setImportPreview(null)}
                className="px-4 py-2 rounded-xl text-slate-600 font-bold text-xs hover:bg-slate-100 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                id="btn-confirm-excel-import"
                onClick={handleConfirmImport}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-colors"
              >
                Confirm & Import
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
