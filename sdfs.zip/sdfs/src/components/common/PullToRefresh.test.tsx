import { describe, it, expect, vi } from 'vitest';
import React from 'react';
import ReactDOMServer from 'react-dom/server';
import { PullToRefresh, PullGestureController } from './PullToRefresh';

describe('Item 6: PullToRefresh Component & Gesture Controller', () => {
  it('renders child content and pull container structure with ReactDOMServer', () => {
    const onRefresh = vi.fn();
    const html = ReactDOMServer.renderToString(
      <PullToRefresh onRefresh={onRefresh}>
        <div id="test-child">পৃষ্ঠার কনটেন্ট</div>
      </PullToRefresh>
    );

    expect(html).toContain('data-testid="pull-to-refresh"');
    expect(html).toContain('data-testid="ptr-indicator"');
    expect(html).toContain('পৃষ্ঠার কনটেন্ট');
  });

  it('pull of more than 70px (> 70px) triggers the reload callback and shows "আপডেট হয়েছে"', async () => {
    const onRefresh = vi.fn().mockImplementation(async () => {
      // Simulate network reload
      await new Promise((resolve) => setTimeout(resolve, 10));
    });

    const controller = new PullGestureController({ onRefresh });

    // 1. Touch start at Y = 100
    const started = controller.handleTouchStart({
      touches: [{ clientY: 100, clientX: 50 }],
      containerScrollTop: 0,
      windowScrollTop: 0,
    });
    expect(started).toBe(true);
    expect(controller.isPulling).toBe(true);

    // 2. Touch move to Y = 185 (delta = 85px > 70px threshold)
    controller.handleTouchMove({
      touches: [{ clientY: 185, clientX: 50 }],
    });
    expect(controller.pullDistance).toBe(85);
    expect(controller.pullDistance > 70).toBe(true);

    // 3. Touch end
    const triggered = await controller.handleTouchEnd();
    expect(triggered).toBe(true);
    expect(onRefresh).toHaveBeenCalledTimes(1);
    expect(controller.showSuccess).toBe(true);
  });

  it('a short pull (<= 70px) does NOT trigger the reload callback', async () => {
    const onRefresh = vi.fn();
    const controller = new PullGestureController({ onRefresh });

    // 1. Touch start at Y = 100
    controller.handleTouchStart({
      touches: [{ clientY: 100, clientX: 50 }],
      containerScrollTop: 0,
      windowScrollTop: 0,
    });
    expect(controller.isPulling).toBe(true);

    // 2. Touch move to Y = 150 (delta = 50px <= 70px threshold)
    controller.handleTouchMove({
      touches: [{ clientY: 150, clientX: 50 }],
    });
    expect(controller.pullDistance).toBe(50);
    expect(controller.pullDistance > 70).toBe(false);

    // 3. Touch end
    const triggered = await controller.handleTouchEnd();
    expect(triggered).toBe(false);
    expect(onRefresh).not.toHaveBeenCalled();
    expect(controller.pullDistance).toBe(0);
  });

  it('pull does NOT fire when touch starts inside a table or modal', () => {
    const onRefresh = vi.fn();
    const controller = new PullGestureController({ onRefresh });

    // Mock table target
    const tableTarget = {
      closest: (selector: string) => (selector.includes('table') ? {} : null),
    };

    const tableResult = controller.handleTouchStart({
      touches: [{ clientY: 100, clientX: 50 }],
      target: tableTarget,
    });
    expect(tableResult).toBe(false);
    expect(controller.isPulling).toBe(false);

    // Mock modal dialog target
    const modalTarget = {
      closest: (selector: string) => (selector.includes('dialog') ? {} : null),
    };

    const modalResult = controller.handleTouchStart({
      touches: [{ clientY: 100, clientX: 50 }],
      target: modalTarget,
    });
    expect(modalResult).toBe(false);
    expect(controller.isPulling).toBe(false);
  });

  it('pull does NOT fire when user is already scrolled down (scrollTop > 0)', () => {
    const onRefresh = vi.fn();
    const controller = new PullGestureController({ onRefresh });

    // Scrolled container
    const containerResult = controller.handleTouchStart({
      touches: [{ clientY: 100, clientX: 50 }],
      containerScrollTop: 45,
    });
    expect(containerResult).toBe(false);
    expect(controller.isPulling).toBe(false);

    // Scrolled window
    const windowResult = controller.handleTouchStart({
      touches: [{ clientY: 100, clientX: 50 }],
      windowScrollTop: 120,
    });
    expect(windowResult).toBe(false);
    expect(controller.isPulling).toBe(false);
  });

  it('cancels pull gesture if swipe is primarily horizontal', () => {
    const onRefresh = vi.fn();
    const controller = new PullGestureController({ onRefresh });

    controller.handleTouchStart({
      touches: [{ clientY: 100, clientX: 100 }],
      containerScrollTop: 0,
      windowScrollTop: 0,
    });
    expect(controller.isPulling).toBe(true);

    // Horizontal swipe: deltaX = 60, deltaY = 10
    controller.handleTouchMove({
      touches: [{ clientY: 110, clientX: 160 }],
    });
    expect(controller.isPulling).toBe(false);
    expect(controller.pullDistance).toBe(0);
  });
});
