import React, { useState, useRef, useEffect, useCallback } from 'react';
import { RefreshCw, CheckCircle2, ArrowDown } from 'lucide-react';

export interface PullToRefreshProps {
  onRefresh: () => Promise<void> | void;
  children: React.ReactNode;
  className?: string;
  disabled?: boolean;
}

export class PullGestureController {
  pullDistance: number = 0;
  isRefreshing: boolean = false;
  showSuccess: boolean = false;
  isPulling: boolean = false;
  startY: number | null = null;
  startX: number | null = null;
  onRefresh: () => Promise<void> | void;
  disabled: boolean;
  onStateChange?: () => void;

  constructor(options: {
    onRefresh: () => Promise<void> | void;
    disabled?: boolean;
    onStateChange?: () => void;
  }) {
    this.onRefresh = options.onRefresh;
    this.disabled = options.disabled ?? false;
    this.onStateChange = options.onStateChange;
  }

  notify() {
    if (this.onStateChange) this.onStateChange();
  }

  handleTouchStart(e: {
    touches: Array<{ clientY: number; clientX: number }>;
    target?: any;
    containerScrollTop?: number;
    windowScrollTop?: number;
  }): boolean {
    if (this.disabled || this.isRefreshing || this.showSuccess) return false;
    if (!e.touches || e.touches.length !== 1) return false;

    const target = e.target;
    // Do NOT fire when user scrolls inside a modal or a table
    if (target && typeof target.closest === 'function') {
      const isInsideRestricted = target.closest(
        'table, thead, tbody, tr, td, th, [role="table"], [role="grid"], [role="dialog"], [aria-modal="true"], .modal-content, .modal-backdrop, .modal-container'
      );
      if (isInsideRestricted) return false;
    }

    const containerScrollTop = e.containerScrollTop ?? 0;
    const windowScrollTop =
      e.windowScrollTop ??
      (typeof window !== 'undefined' ? window.scrollY || document.documentElement?.scrollTop || 0 : 0);

    if (containerScrollTop > 0 || windowScrollTop > 0) {
      return false;
    }

    // Check if any scrollable parent of target is scrolled
    let el = target;
    while (el && el !== document?.body) {
      if (el.scrollTop > 0) {
        return false;
      }
      el = el.parentElement;
    }

    this.startY = e.touches[0].clientY;
    this.startX = e.touches[0].clientX;
    this.isPulling = true;
    this.pullDistance = 0;
    this.notify();
    return true;
  }

  handleTouchMove(e: {
    touches: Array<{ clientY: number; clientX: number }>;
  }): void {
    if (!this.isPulling || this.startY === null || this.startX === null) {
      return;
    }
    if (!e.touches || e.touches.length === 0) return;

    const currentY = e.touches[0].clientY;
    const currentX = e.touches[0].clientX;
    const deltaY = currentY - this.startY;
    const deltaX = currentX - this.startX;

    // Ignore if user is swiping horizontally
    if (Math.abs(deltaX) > Math.abs(deltaY) && this.pullDistance === 0) {
      this.isPulling = false;
      this.notify();
      return;
    }

    if (deltaY <= 0) {
      this.pullDistance = 0;
      this.notify();
      return;
    }

    // Cap pull distance at 120px
    this.pullDistance = Math.min(deltaY, 120);
    this.notify();
  }

  async handleTouchEnd(): Promise<boolean> {
    if (!this.isPulling) return false;
    this.isPulling = false;
    this.startY = null;
    this.startX = null;

    // Threshold is 70px: a pull of more than 70px triggers the reload callback
    if (this.pullDistance > 70 && !this.isRefreshing) {
      this.isRefreshing = true;
      this.pullDistance = 50;
      this.notify();

      try {
        await this.onRefresh();
        this.showSuccess = true;
      } catch (err) {
        console.error('Pull-to-refresh reload error:', err);
      } finally {
        this.isRefreshing = false;
        this.notify();
        setTimeout(() => {
          this.showSuccess = false;
          this.pullDistance = 0;
          this.notify();
        }, 1500);
      }
      return true;
    } else {
      // Short pull (<= 70px) does not reload
      this.pullDistance = 0;
      this.notify();
      return false;
    }
  }

  handleTouchCancel(): void {
    this.isPulling = false;
    this.startY = null;
    this.startX = null;
    this.pullDistance = 0;
    this.notify();
  }
}

export const PullToRefresh: React.FC<PullToRefreshProps> = ({
  onRefresh,
  children,
  className = '',
  disabled = false,
}) => {
  const [, setTick] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const controllerRef = useRef<PullGestureController | null>(null);

  if (!controllerRef.current) {
    controllerRef.current = new PullGestureController({
      onRefresh,
      disabled,
      onStateChange: () => setTick((t) => t + 1),
    });
  } else {
    controllerRef.current.onRefresh = onRefresh;
    controllerRef.current.disabled = disabled;
  }

  const controller = controllerRef.current;
  const [prefersReducedMotion, setPrefersReducedMotion] = useState<boolean>(false);

  useEffect(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
      setPrefersReducedMotion(mediaQuery.matches);
      const listener = (e: MediaQueryListEvent) => setPrefersReducedMotion(e.matches);
      if (mediaQuery.addEventListener) {
        mediaQuery.addEventListener('change', listener);
        return () => mediaQuery.removeEventListener('change', listener);
      }
    }
  }, []);

  const onTouchStart = useCallback(
    (e: React.TouchEvent<HTMLDivElement>) => {
      const container = containerRef.current;
      controller.handleTouchStart({
        touches: Array.from(e.touches).map((t) => ({ clientY: t.clientY, clientX: t.clientX })),
        target: e.target,
        containerScrollTop: container ? container.scrollTop : 0,
        windowScrollTop:
          typeof window !== 'undefined' ? window.scrollY || document.documentElement?.scrollTop : 0,
      });
    },
    [controller]
  );

  const onTouchMove = useCallback(
    (e: React.TouchEvent<HTMLDivElement>) => {
      controller.handleTouchMove({
        touches: Array.from(e.touches).map((t) => ({ clientY: t.clientY, clientX: t.clientX })),
      });
    },
    [controller]
  );

  const onTouchEnd = useCallback(() => {
    controller.handleTouchEnd();
  }, [controller]);

  const onTouchCancel = useCallback(() => {
    controller.handleTouchCancel();
  }, [controller]);

  const isTriggered = controller.pullDistance > 70;
  const isVisible = controller.pullDistance > 10 || controller.isRefreshing || controller.showSuccess;
  const height =
    controller.isRefreshing || controller.showSuccess
      ? 48
      : isVisible
      ? Math.min(controller.pullDistance, 60)
      : 0;

  return (
    <div
      ref={containerRef}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      onTouchCancel={onTouchCancel}
      data-testid="pull-to-refresh"
      className={`relative ${className}`}
    >
      {/* Pull Indicator Banner */}
      <div
        data-testid="ptr-indicator"
        aria-live="polite"
        className={`w-full overflow-hidden flex items-center justify-center pointer-events-none select-none ${
          prefersReducedMotion ? '' : 'transition-all duration-200 ease-out'
        }`}
        style={{
          height: `${height}px`,
          opacity: isVisible ? 1 : 0,
        }}
      >
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 text-white text-xs font-semibold shadow-md">
          {controller.showSuccess ? (
            <>
              <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
              <span data-testid="ptr-status-text" className="text-emerald-300 font-bold">
                আপডেট হয়েছে
              </span>
            </>
          ) : controller.isRefreshing ? (
            <>
              <RefreshCw
                className={`h-4 w-4 text-emerald-400 shrink-0 ${
                  prefersReducedMotion ? '' : 'animate-spin'
                }`}
              />
              <span data-testid="ptr-status-text" className="text-slate-200">
                রিফ্রেশ হচ্ছে...
              </span>
            </>
          ) : isTriggered ? (
            <>
              <RefreshCw className="h-4 w-4 text-emerald-400 shrink-0" />
              <span data-testid="ptr-status-text" className="text-emerald-300 font-bold">
                ছেড়ে দিন, রিফ্রেশ হবে
              </span>
            </>
          ) : (
            <>
              <ArrowDown className="h-4 w-4 text-slate-300 shrink-0" />
              <span data-testid="ptr-status-text" className="text-slate-300">
                টেনে নামান...
              </span>
            </>
          )}
        </div>
      </div>

      {children}
    </div>
  );
};
