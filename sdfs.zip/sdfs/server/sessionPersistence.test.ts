import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import http from 'http';
import { AddressInfo } from 'net';
import bcrypt from 'bcryptjs';
import { createApp } from './app';
import { getFirestore, Collections, isUsingMock } from './db';
import { COOKIE_NAME } from './auth';

describe('Item 2: Session Persistence Across App Instances', () => {
  let server1: http.Server;
  let baseUrl1: string;
  let server2: http.Server;
  let baseUrl2: string;

  const testMember = {
    id: 'mem-session-test',
    fullName: 'Persistent Test User',
    email: 'persistent@session.test',
    password: 'password123',
    isActive: true,
    joinDate: '2026-01-01',
    initialDeposit: 0,
  };

  beforeAll(async () => {
    // Insert test member into DB with hashed password
    const db = getFirestore();
    const hash = bcrypt.hashSync(testMember.password, 10);
    await db.collection(Collections.MEMBERS).doc(testMember.id).set({
      ...testMember,
      password: hash,
    });

    const app1 = createApp();
    server1 = app1.listen(0);
    const port1 = (server1.address() as AddressInfo).port;
    baseUrl1 = `http://127.0.0.1:${port1}`;
  });

  afterAll(async () => {
    if (server1) {
      await new Promise<void>((resolve) => server1.close(() => resolve()));
    }
    if (server2) {
      await new Promise<void>((resolve) => server2.close(() => resolve()));
    }
  });

  it('reports database as mock in /api/health when using mock database', async () => {
    const res = await fetch(`${baseUrl1}/api/health`);
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.status).toBe('ok');
    if (isUsingMock()) {
      expect(body.database).toBe('mock');
    }
  }, 15000);

  it('logs in, GET /auth/me returns 200 with cookie, and works on newly created app instance', async () => {
    // 1. Login on app1
    const loginRes = await fetch(`${baseUrl1}/api/mess/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: testMember.email,
        password: testMember.password,
      }),
    });

    expect(loginRes.status).toBe(200);
    const loginData = await loginRes.json();
    expect(loginData.success).toBe(true);
    expect(loginData.user.email).toBe(testMember.email);
    expect(loginData.user.memberId).toBe(testMember.id);

    // Extract cookie from response headers
    const rawCookies = loginRes.headers.get('set-cookie');
    expect(rawCookies).toBeTruthy();
    // Parse messmate_token value
    const match = rawCookies?.match(new RegExp(`${COOKIE_NAME}=([^;]+)`));
    expect(match).toBeTruthy();
    const cookieHeader = `${COOKIE_NAME}=${match![1]}`;

    // 2. GET /auth/me on app1 returns 200
    const meRes1 = await fetch(`${baseUrl1}/api/mess/auth/me`, {
      headers: { Cookie: cookieHeader },
    });
    expect(meRes1.status).toBe(200);
    const meData1 = await meRes1.json();
    expect(meData1.success).toBe(true);
    expect(meData1.user.email).toBe(testMember.email);
    expect(meData1.user.memberId).toBe(testMember.id);

    // 3. Create a SECOND app instance against the same database
    const app2 = createApp();
    server2 = app2.listen(0);
    const port2 = (server2.address() as AddressInfo).port;
    baseUrl2 = `http://127.0.0.1:${port2}`;

    // 4. GET /auth/me on app2 using the exact same cookie succeeds seamlessly
    const meRes2 = await fetch(`${baseUrl2}/api/mess/auth/me`, {
      headers: { Cookie: cookieHeader },
    });
    expect(meRes2.status).toBe(200);
    const meData2 = await meRes2.json();
    expect(meData2.success).toBe(true);
    expect(meData2.user.email).toBe(testMember.email);
    expect(meData2.user.memberId).toBe(testMember.id);
    expect(meData2.user.name).toBe(testMember.fullName);
  }, 15000);
});
