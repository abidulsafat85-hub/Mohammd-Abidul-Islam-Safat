import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { Repository, ADMIN_EMAIL } from './repository';

export function getJwtSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (process.env.NODE_ENV === 'test') {
    return secret && secret.length >= 32
      ? secret
      : 'test-jwt-secret-minimum-32-chars-long-for-vitest-only';
  }
  if (!secret || secret.trim().length < 32) {
    throw new Error(
      'FATAL: JWT_SECRET environment variable is missing or shorter than 32 characters. Server startup aborted for security.'
    );
  }
  return secret.trim();
}

export const JWT_SECRET = getJwtSecret();

export const COOKIE_NAME = 'messmate_token';

export const ADMIN_SESSION_LIFETIME_MS = 12 * 60 * 60 * 1000; // 12 hours
export const MEMBER_SESSION_LIFETIME_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

export interface AuthJwtPayload {
  sessionId: string;
  userId: string;
  memberId: string;
  email: string;
  role: 'admin' | 'member';
  mustChangePassword?: boolean;
}

export function signAuthToken(payload: AuthJwtPayload): string {
  const expiresIn = payload.role === 'admin' ? '12h' : '30d';
  const cleanPayload: AuthJwtPayload = {
    sessionId: payload.sessionId,
    userId: payload.userId,
    memberId: payload.memberId,
    email: payload.email,
    role: payload.role,
    ...(payload.mustChangePassword !== undefined ? { mustChangePassword: payload.mustChangePassword } : {}),
  };
  return jwt.sign(cleanPayload, JWT_SECRET, { expiresIn });
}

export function isRequestSecure(req?: Request): boolean {
  if (!req) return false;
  return Boolean(req.secure || req.headers['x-forwarded-proto'] === 'https');
}

export function setTokenCookie(
  req: Request | undefined,
  res: Response,
  token: string,
  role: 'admin' | 'member' = 'member'
): void {
  const secure = isRequestSecure(req);
  const allowCrossSite = process.env.ALLOW_CROSS_SITE_COOKIES === 'true';
  const sameSite: 'none' | 'lax' = allowCrossSite && secure ? 'none' : 'lax';
  const maxAge = role === 'admin' ? ADMIN_SESSION_LIFETIME_MS : MEMBER_SESSION_LIFETIME_MS;

  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    secure,
    sameSite,
    partitioned: allowCrossSite && secure,
    maxAge,
    path: '/',
  });
}

export function refreshSessionCookie(req: Request, res: Response, payload: AuthJwtPayload): void {
  if (payload.role === 'member' && !(req as any)._sessionRefreshed) {
    (req as any)._sessionRefreshed = true;
    const refreshedToken = signAuthToken(payload);
    setTokenCookie(req, res, refreshedToken, 'member');
  }
}

export function clearTokenCookie(res: Response): void {
  // 1. Production Partitioned + SameSite: None + Secure
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    partitioned: true,
    path: '/',
  });
  // 2. Production non-partitioned + SameSite: None + Secure
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    path: '/',
  });
  // 3. Development SameSite: Lax
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
  });
  // 4. Default plain cookie
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    path: '/',
  });
}

export function extractAuthToken(req: Request): string | null {
  if (req.cookies && req.cookies[COOKIE_NAME]) {
    return req.cookies[COOKIE_NAME];
  }
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7).trim();
  }
  return null;
}

export function verifyAuthToken(token: string): AuthJwtPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as AuthJwtPayload;
  } catch {
    return null;
  }
}

// Middleware: Require valid session in Firestore & valid JWT (Part G)
export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  // Prevent browser back-button caching of private responses (Part G rule 5)
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');

  const token = extractAuthToken(req);
  if (!token) {
    return res.status(401).json({ success: false, error: 'লগইন করা আবশ্যক।' });
  }

  const payload = verifyAuthToken(token);
  if (!payload) {
    clearTokenCookie(res);
    return res.status(401).json({ success: false, error: 'সেশন মেয়াদোত্তীর্ণ হয়েছে। পুনরায় লগইন করুন।' });
  }

  // Check if session record is still active in Firestore
  if (payload.sessionId) {
    const session = await Repository.getSession(payload.sessionId);
    if (!session) {
      clearTokenCookie(res);
      return res.status(401).json({ success: false, error: 'সেশন বাতিল করা হয়েছে। পুনরায় লগইন করুন।' });
    }
  }

  (req as any).user = payload;
  refreshSessionCookie(req, res, payload);
  next();
}

// Middleware: Require Admin role
export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');

  const token = extractAuthToken(req);
  if (!token) {
    return res.status(401).json({ success: false, error: 'এডমিন লগইন আবশ্যক।' });
  }

  const payload = verifyAuthToken(token);
  if (!payload) {
    clearTokenCookie(res);
    return res.status(401).json({ success: false, error: 'সেশন মেয়াদোত্তীর্ণ হয়েছে।' });
  }

  if (payload.sessionId) {
    const session = await Repository.getSession(payload.sessionId);
    if (!session) {
      clearTokenCookie(res);
      return res.status(401).json({ success: false, error: 'সেশন বাতিল করা হয়েছে।' });
    }
  }

  if (payload.role !== 'admin' || payload.email.trim().toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
    return res.status(403).json({ success: false, error: 'শুধুমাত্র মেস এডমিনদের জন্য অনুমোদিত।' });
  }

  (req as any).user = payload;
  next();
}

// Middleware: Member route isolation (member can access only their own data; admin has access)
export async function requireMemberOrAdmin(req: Request, res: Response, next: NextFunction) {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');

  const token = extractAuthToken(req);
  if (!token) {
    return res.status(401).json({ success: false, error: 'লগইন আবশ্যক।' });
  }

  const payload = verifyAuthToken(token);
  if (!payload) {
    clearTokenCookie(res);
    return res.status(401).json({ success: false, error: 'সেশন মেয়াদোত্তীর্ণ হয়েছে।' });
  }

  if (payload.sessionId) {
    const session = await Repository.getSession(payload.sessionId);
    if (!session) {
      clearTokenCookie(res);
      return res.status(401).json({ success: false, error: 'সেশন বাতিল করা হয়েছে।' });
    }
  }

  (req as any).user = payload;

  const targetMemberId = req.params.memberId;
  const isAdmin = payload.role === 'admin' && payload.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase();
  const isTargetMember = payload.memberId === targetMemberId;

  if (isAdmin || isTargetMember) {
    refreshSessionCookie(req, res, payload);
    return next();
  }

  console.warn(
    `[requireMemberOrAdmin 403] payload.memberId=${payload.memberId}, req.params.memberId=${targetMemberId}, payload.role=${payload.role}, email=${payload.email}`
  );

  return res.status(403).json({
    success: false,
    error: 'অন্য মেম্বারের তথ্যে প্রবেশাধিকার নেই।',
  });
}
