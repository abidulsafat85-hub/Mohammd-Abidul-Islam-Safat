import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import http from 'http';
import { AddressInfo } from 'net';
import { createApp } from './app';
import { getFirestore, Collections } from './db';
import { Repository, ADMIN_EMAIL } from './repository';
import { signAuthToken, COOKIE_NAME } from './auth';

describe('Item 3: Settings Save and Collection Non-Interference', () => {
  let server: http.Server;
  let baseUrl: string;
  let adminCookie: string;
  let memberCookie: string;

  const testMemberId = 'mem-settings-test-1';
  const testMealId = 'meal-settings-test-1';
  const testDepositId = 'dep-settings-test-1';
  const testBazarId = 'baz-settings-test-1';
  const testFixedId = 'fix-settings-test-1';

  beforeAll(async () => {
    const db = getFirestore();

    // 1. Seed other collections
    await db.collection(Collections.MEMBERS).doc(testMemberId).set({
      id: testMemberId,
      fullName: 'Original Member',
      email: 'orig@test.com',
      isActive: true,
    });

    await db.collection(Collections.MEALS).doc(testMealId).set({
      id: testMealId,
      memberId: testMemberId,
      date: '2026-10-01',
      mealCount: 2,
    });

    await db.collection(Collections.DEPOSITS).doc(testDepositId).set({
      id: testDepositId,
      memberId: testMemberId,
      amount: 500,
      date: '2026-10-01',
      status: 'approved',
    });

    await db.collection(Collections.BAZAR).doc(testBazarId).set({
      id: testBazarId,
      date: '2026-10-01',
      amount: 350,
      description: 'Fish and vegetables',
    });

    await db.collection(Collections.FIXED_EXPENSES).doc(testFixedId).set({
      id: testFixedId,
      month: '2026-10',
      title: 'WiFi Bill',
      amount: 600,
    });

    // 2. Admin session & token
    const adminSessId = `sess_adm_${Date.now()}`;
    await Repository.createSession(adminSessId, 'admin-1', 'admin', ADMIN_EMAIL, 'mem-1');
    const adminToken = signAuthToken({
      sessionId: adminSessId,
      userId: 'admin-1',
      memberId: 'mem-1',
      email: ADMIN_EMAIL,
      role: 'admin',
    });
    adminCookie = `${COOKIE_NAME}=${adminToken}`;

    // 3. Member session & token
    const memSessId = `sess_mem_${Date.now()}`;
    await Repository.createSession(memSessId, testMemberId, 'member', 'orig@test.com', testMemberId);
    const memberToken = signAuthToken({
      sessionId: memSessId,
      userId: testMemberId,
      memberId: testMemberId,
      email: 'orig@test.com',
      role: 'member',
    });
    memberCookie = `${COOKIE_NAME}=${memberToken}`;

    // 4. Start app server
    const app = createApp();
    server = app.listen(0);
    const port = (server.address() as AddressInfo).port;
    baseUrl = `http://127.0.0.1:${port}`;
  });

  afterAll(async () => {
    if (server) {
      await new Promise<void>((resolve) => server.close(() => resolve()));
    }
  });

  it('PUT /api/mess/admin/settings saves meal rate, merges settings, and leaves all other collections untouched', async () => {
    const db = getFirestore();

    // Snapshot counts before saving settings
    const memSnapBefore = await db.collection(Collections.MEMBERS).get();
    const mealsSnapBefore = await db.collection(Collections.MEALS).get();
    const depositsSnapBefore = await db.collection(Collections.DEPOSITS).get();
    const bazarSnapBefore = await db.collection(Collections.BAZAR).get();
    const fixedSnapBefore = await db.collection(Collections.FIXED_EXPENSES).get();

    // Perform PUT settings
    const res = await fetch(`${baseUrl}/api/mess/admin/settings`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Cookie: adminCookie,
      },
      body: JSON.stringify({
        fixedMealRate: 65,
        messName: 'Updated Test Mess',
        unknownHackerField: 'should_be_ignored',
      }),
    });

    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.success).toBe(true);
    expect(body.data.fixedMealRate).toBe(65);
    expect(body.data.messName).toBe('Updated Test Mess');
    expect(body.data.unknownHackerField).toBeUndefined();

    // Verify settings doc in database
    const settingsDoc = await db.collection(Collections.SETTINGS).doc('app_settings').get();
    expect(settingsDoc.data()?.fixedMealRate).toBe(65);
    expect(settingsDoc.data()?.messName).toBe('Updated Test Mess');

    // Verify EVERY other collection is completely unchanged
    const memSnapAfter = await db.collection(Collections.MEMBERS).get();
    expect(memSnapAfter.docs.length).toBe(memSnapBefore.docs.length);
    expect(memSnapAfter.docs.map((d: any) => d.id)).toEqual(memSnapBefore.docs.map((d: any) => d.id));

    const mealsSnapAfter = await db.collection(Collections.MEALS).get();
    expect(mealsSnapAfter.docs.length).toBe(mealsSnapBefore.docs.length);
    expect(mealsSnapAfter.docs.map((d: any) => d.id)).toEqual(mealsSnapBefore.docs.map((d: any) => d.id));

    const depositsSnapAfter = await db.collection(Collections.DEPOSITS).get();
    expect(depositsSnapAfter.docs.length).toBe(depositsSnapBefore.docs.length);
    expect(depositsSnapAfter.docs.map((d: any) => d.id)).toEqual(depositsSnapBefore.docs.map((d: any) => d.id));

    const bazarSnapAfter = await db.collection(Collections.BAZAR).get();
    expect(bazarSnapAfter.docs.length).toBe(bazarSnapBefore.docs.length);
    expect(bazarSnapAfter.docs.map((d: any) => d.id)).toEqual(bazarSnapBefore.docs.map((d: any) => d.id));

    const fixedSnapAfter = await db.collection(Collections.FIXED_EXPENSES).get();
    expect(fixedSnapAfter.docs.length).toBe(fixedSnapBefore.docs.length);
    expect(fixedSnapAfter.docs.map((d: any) => d.id)).toEqual(fixedSnapBefore.docs.map((d: any) => d.id));
  });

  it('rejects invalid meal rate with 400', async () => {
    const res = await fetch(`${baseUrl}/api/mess/admin/settings`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Cookie: adminCookie,
      },
      body: JSON.stringify({
        fixedMealRate: -5,
      }),
    });

    expect(res.status).toBe(400);
    const body = await res.json();
    expect(body.success).toBe(false);
  });

  it('rejects non-admin users with 403', async () => {
    const res = await fetch(`${baseUrl}/api/mess/admin/settings`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Cookie: memberCookie,
      },
      body: JSON.stringify({
        fixedMealRate: 50,
      }),
    });

    expect(res.status).toBe(403);
  });
});
