import { describe, it, expect } from 'vitest';
import { getJwtSecret } from './auth';

describe('Item 1: Security - JWT Secret Enforcement', () => {
  it('fails with clear error if JWT_SECRET is missing and NODE_ENV is production/development', () => {
    const originalEnv = process.env.NODE_ENV;
    const originalSecret = process.env.JWT_SECRET;
    try {
      process.env.NODE_ENV = 'production';
      delete process.env.JWT_SECRET;
      expect(() => getJwtSecret()).toThrow(/JWT_SECRET environment variable is missing or shorter than 32 characters/);
    } finally {
      process.env.NODE_ENV = originalEnv;
      if (originalSecret) process.env.JWT_SECRET = originalSecret;
    }
  });

  it('fails with clear error if JWT_SECRET is shorter than 32 characters', () => {
    const originalEnv = process.env.NODE_ENV;
    const originalSecret = process.env.JWT_SECRET;
    try {
      process.env.NODE_ENV = 'production';
      process.env.JWT_SECRET = 'short-secret-under-32-chars';
      expect(() => getJwtSecret()).toThrow(/JWT_SECRET environment variable is missing or shorter than 32 characters/);
    } finally {
      process.env.NODE_ENV = originalEnv;
      if (originalSecret) process.env.JWT_SECRET = originalSecret;
    }
  });

  it('accepts valid JWT_SECRET of 32 or more characters', () => {
    const originalEnv = process.env.NODE_ENV;
    const originalSecret = process.env.JWT_SECRET;
    try {
      process.env.NODE_ENV = 'production';
      process.env.JWT_SECRET = 'this-is-a-valid-production-jwt-secret-at-least-32-chars';
      expect(getJwtSecret()).toBe('this-is-a-valid-production-jwt-secret-at-least-32-chars');
    } finally {
      process.env.NODE_ENV = originalEnv;
      if (originalSecret) process.env.JWT_SECRET = originalSecret;
    }
  });
});
