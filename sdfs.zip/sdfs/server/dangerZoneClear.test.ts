import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import http from 'http';
import { AddressInfo } from 'net';
import bcrypt from 'bcryptjs';
import { createApp } from './app';
import { getFirestore, Collections } from './db';
import { Repository, ADMIN_EMAIL } from './repository';
import { signAuthToken, COOKIE_NAME } from './auth';

describe('Item 4: Destructive Operations Danger Zone & Audit Log', () => {
  let server: http.Server;
  let baseUrl: string;
  let adminCookie: string;
  let memberCookie: string;

  const adminPassword = 'admin-secure-test-pass';

  beforeAll(async () => {
    const db = getFirestore();

    // 1. Ensure admin account with known password
    const hashed = bcrypt.hashSync(adminPassword, 10);
    await db.collection(Collections.ADMIN_ACCOUNT).doc(ADMIN_EMAIL).set({
      email: ADMIN_EMAIL,
      passwordHash: hashed,
      mustChangePassword: false,
    });

    // 2. Admin session & token
    const adminSessId = `sess_danger_adm_${Date.now()}`;
    await Repository.createSession(adminSessId, 'admin-1', 'admin', ADMIN_EMAIL, 'mem-1');
    const adminToken = signAuthToken({
      sessionId: adminSessId,
      userId: 'admin-1',
      memberId: 'mem-1',
      email: ADMIN_EMAIL,
      role: 'admin',
    });
    adminCookie = `${COOKIE_NAME}=${adminToken}`;

    // 3. Member session & token
    const memSessId = `sess_danger_mem_${Date.now()}`;
    await Repository.createSession(memSessId, 'mem-danger', 'member', 'danger@test.com', 'mem-danger');
    const memberToken = signAuthToken({
      sessionId: memSessId,
      userId: 'mem-danger',
      memberId: 'mem-danger',
      email: 'danger@test.com',
      role: 'member',
    });
    memberCookie = `${COOKIE_NAME}=${memberToken}`;

    // 4. Start app
    const app = createApp();
    server = app.listen(0);
    const port = (server.address() as AddressInfo).port;
    baseUrl = `http://127.0.0.1:${port}`;
  });

  afterAll(async () => {
    if (server) {
      await new Promise<void>((resolve) => server.close(() => resolve()));
    }
  });

  it('rejects without exact Bangla confirmation word "মুছুন" with 400', async () => {
    const res = await fetch(`${baseUrl}/api/mess/admin/danger-clear-data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: adminCookie,
      },
      body: JSON.stringify({
        confirmationWord: 'clear',
        adminPassword: adminPassword,
      }),
    });

    expect(res.status).toBe(400);
    const body = await res.json();
    expect(body.success).toBe(false);
    expect(body.error).toContain('মুছুন');
  });

  it('rejects with incorrect admin password with 401', async () => {
    const res = await fetch(`${baseUrl}/api/mess/admin/danger-clear-data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: adminCookie,
      },
      body: JSON.stringify({
        confirmationWord: 'মুছুন',
        adminPassword: 'wrong-password-123',
      }),
    });

    expect(res.status).toBe(401);
    const body = await res.json();
    expect(body.success).toBe(false);
  });

  it('rejects non-admin users with 403', async () => {
    const res = await fetch(`${baseUrl}/api/mess/admin/danger-clear-data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: memberCookie,
      },
      body: JSON.stringify({
        confirmationWord: 'মুছুন',
        adminPassword: adminPassword,
      }),
    });

    expect(res.status).toBe(403);
  });

  it('successfully clears operational data, preserves admin account, and writes audit log entry', async () => {
    const db = getFirestore();

    // Seed test data in operational collections
    await db.collection(Collections.MEMBERS).doc('mem-to-wipe').set({
      id: 'mem-to-wipe',
      fullName: 'To be wiped',
    });
    await db.collection(Collections.MEALS).doc('meal-to-wipe').set({
      id: 'meal-to-wipe',
      mealCount: 2,
    });
    await db.collection(Collections.DEPOSITS).doc('dep-to-wipe').set({
      id: 'dep-to-wipe',
      amount: 500,
    });
    await db.collection(Collections.BAZAR).doc('baz-to-wipe').set({
      id: 'baz-to-wipe',
      amount: 300,
    });
    await db.collection(Collections.FIXED_EXPENSES).doc('fix-to-wipe').set({
      id: 'fix-to-wipe',
      amount: 200,
    });

    // Execute Danger Zone clear
    const res = await fetch(`${baseUrl}/api/mess/admin/danger-clear-data`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: adminCookie,
      },
      body: JSON.stringify({
        confirmationWord: 'মুছুন',
        adminPassword: adminPassword,
      }),
    });

    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.success).toBe(true);

    // Verify operational collections are cleared
    const memSnap = await db.collection(Collections.MEMBERS).get();
    expect(memSnap.docs.length).toBe(0);

    const mealSnap = await db.collection(Collections.MEALS).get();
    expect(mealSnap.docs.length).toBe(0);

    const depSnap = await db.collection(Collections.DEPOSITS).get();
    expect(depSnap.docs.length).toBe(0);

    const bazSnap = await db.collection(Collections.BAZAR).get();
    expect(bazSnap.docs.length).toBe(0);

    const fixSnap = await db.collection(Collections.FIXED_EXPENSES).get();
    expect(fixSnap.docs.length).toBe(0);

    // Verify Admin account is preserved
    const adminDoc = await db.collection(Collections.ADMIN_ACCOUNT).doc(ADMIN_EMAIL).get();
    expect(adminDoc.exists).toBe(true);

    // Verify Audit Log entry exists
    const auditLogs = await Repository.getAuditLogs();
    const clearEntry = auditLogs.find((entry) => entry.action === 'CLEAR_ALL_DATA');
    expect(clearEntry).toBeTruthy();
    expect(clearEntry.performedBy).toBe(ADMIN_EMAIL);
    expect(clearEntry.timestamp).toBeTruthy();
  });
});
